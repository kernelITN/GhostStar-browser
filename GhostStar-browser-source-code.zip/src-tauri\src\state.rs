//! Модели состояния браузера.
//!
//! `BrowserState` живёт внутри `tauri::State<Mutex<...>>`.
//! `AppState` — его «публичная» копия, которую получит фронтенд через `invoke('state')`.

use std::{collections::BTreeMap, path::PathBuf};

use serde::{Deserialize, Deserializer, Serialize};
use tauri::Manager;

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TabError {
    pub code: i32,
    pub description: String,
    pub url: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TabInfo {
    pub id: u32,
    pub title: String,
    /// Реальный URL. Для новой вкладки — пустая строка.
    pub url: String,
    /// Что показываем в адресной строке.
    pub display_url: String,
    pub favicon: Option<String>,
    pub loading: bool,
    pub can_go_back: bool,
    pub can_go_forward: bool,
    pub is_new_tab: bool,
    pub audible: bool,
    pub error: Option<TabError>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ThemeInfo {
    pub scheme: String,
    pub accent: String,
    pub motion: String,
}

/// Разреженный пресет редактора UI. Храним только то, что пользователь изменил.
/// Значения — числа, единицы и допустимые диапазоны задаёт реестр на фронтенде.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", default)]
pub struct UiTheme {
    pub version: u8,
    pub overrides: BTreeMap<String, serde_json::Value>,
}

impl Default for UiTheme {
    fn default() -> Self {
        Self {
            version: 1,
            overrides: BTreeMap::new(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct WindowInfo {
    pub maximized: bool,
    pub fullscreen: bool,
    pub focused: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AppState {
    pub tabs: Vec<TabInfo>,
    pub active_id: Option<u32>,
    pub theme: ThemeInfo,
    pub window: WindowInfo,
    pub search_engine: String,
    pub settings_open: bool,
    pub downloads_open: bool,
    pub ui_editor_open: bool,
}

/// Элемент списка загрузок (общий для Rust и рендерера).
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DownloadItem {
    pub id: String,
    pub filename: String,
    pub url: String,
    pub save_path: String,
    pub total_bytes: Option<u64>,
    pub received_bytes: u64,
    pub state: String,
    pub start_time: u64,
    pub end_time: Option<u64>,
    pub paused: Option<bool>,
}

/// Serde по умолчанию превращает JSON `null` во внешний `None`, из-за чего
/// команда не отличала «поле прислали с null» от «поля не было». Этот
/// десериализатор возвращает `Some(None)` для присланного null — тогда
/// «Цвет системы» и сброс папки загрузок начинают работать.
fn deserialize_present_option<'de, D, T>(deserializer: D) -> Result<Option<Option<T>>, D::Error>
where
    D: Deserializer<'de>,
    T: Deserialize<'de>,
{
    Option::<T>::deserialize(deserializer).map(Some)
}

/// Частичное обновление настроек из фронтенда.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(rename_all = "camelCase", default)]
pub struct SettingsPatch {
    pub scheme: Option<String>,
    /// `Some(None)` = «цвет системы», `None` = не менять.
    #[serde(default, deserialize_with = "deserialize_present_option")]
    pub accent: Option<Option<String>>,
    pub search_engine: Option<String>,
    /// `Some(None)` = «папка по умолчанию», `None` = не менять.
    #[serde(default, deserialize_with = "deserialize_present_option")]
    pub download_path: Option<Option<String>>,
    /// Стиль окон «Загрузки»/«Настройки»: pattern | fullscreen | panel.
    pub dialog_style: Option<String>,
    /// Язык интерфейса; неизвестные значения нормализуются в `ru`.
    pub language: Option<String>,
    /// `Some(None)` = «как сейчас», `None` = не менять. Число 0–100 — процент
    /// исходной насыщенности акцента.
    #[serde(default, deserialize_with = "deserialize_present_option")]
    pub saturation: Option<Option<i32>>,
    /// Пресет курсора; неизвестные значения нормализуются в `ghost`.
    pub cursor_preset: Option<String>,
    /// Master-выключатель звуков. Не включается сам.
    pub sounds: Option<bool>,
    /// Пресет иконки окна/панели задач.
    pub app_icon: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", default)]
pub struct Settings {
    pub scheme: String,
    pub accent: Option<String>,
    pub search_engine: String,
    pub download_path: Option<String>,
    /// Правки редактора UI; отсутствует в старых settings.json — тогда дефолт.
    pub ui_theme: UiTheme,
    /// Стиль окон «Загрузки»/«Настройки»: pattern | fullscreen | panel.
    pub dialog_style: String,
    /// Язык интерфейса: ru | en | zh | tr | fr | de | es | ja.
    pub language: String,
    /// `None` = как сейчас; `Some(0..=100)` = доля исходной насыщенности.
    pub saturation: Option<u8>,
    /// Пресет курсора: ghost | classic | neon | outline | minimal.
    pub cursor_preset: String,
    /// Звуки браузера выключены по умолчанию — без автовоспроизведения.
    pub sounds: bool,
    /// Иконка окна/панели задач: default + 15 пресетов.
    pub app_icon: String,
}

/// Возвращает только поддерживаемые стили — битые значения из settings.json
/// не должны ломать вёрстку модалок.
pub fn normalize_dialog_style(value: &str) -> &'static str {
    match value {
        "fullscreen" => "fullscreen",
        "panel" => "panel",
        _ => "pattern",
    }
}

/// Язык по умолчанию — русский. Старые settings.json без поля language
/// продолжают работать: Normalize подставит `ru`.
pub fn normalize_language(value: &str) -> &'static str {
    match value {
        "en" => "en",
        "zh" => "zh",
        "tr" => "tr",
        "fr" => "fr",
        "de" => "de",
        "es" => "es",
        "ja" => "ja",
        _ => "ru",
    }
}

/// Пресет курсора из settings.json: битые значения не ломают курсор.
pub fn normalize_cursor_preset(value: &str) -> &'static str {
    match value {
        "classic" => "classic",
        "neon" => "neon",
        "outline" => "outline",
        "minimal" => "minimal",
        _ => "ghost",
    }
}

/// Пресет иконки окна/панели задач. `default` = текущая иконка приложения.
pub fn normalize_app_icon(value: &str) -> &'static str {
    match value {
        "custom" => "custom",
        "classic" => "classic",
        "darkEdge" => "darkEdge",
        "cyberGlow" => "cyberGlow",
        "materialLight" => "materialLight",
        "minimal" => "minimal",
        "purpleClassic" => "purpleClassic",
        "monochrome" => "monochrome",
        "classicRed" => "classicRed",
        "neon" => "neon",
        "cosmicOrbit" => "cosmicOrbit",
        "aquaWave" => "aquaWave",
        "armorPlate" => "armorPlate",
        "pixel" => "pixel",
        "lineArt" => "lineArt",
        "voidMatrix" => "voidMatrix",
        _ => "default",
    }
}

pub fn custom_app_icon_path(app: &tauri::AppHandle) -> Option<std::path::PathBuf> {
    app.path().app_config_dir().ok().map(|dir| dir.join("custom-app-icon.png"))
}

/// Значение слайдера: только 0–100. Всё остальное — «как сейчас».
pub fn normalize_saturation(value: &Option<i32>) -> Option<u8> {
    match value {
        Some(value) if (0..=100).contains(value) => Some(*value as u8),
        _ => None,
    }
}

fn hsl_to_rgb(hue: f64, saturation: f64, lightness: f64) -> (u8, u8, u8) {
    let chroma = (1.0 - (2.0 * lightness - 1.0).abs()) * saturation;
    let hp = hue * 6.0;
    let second = chroma * (1.0 - ((hp % 2.0) - 1.0).abs());
    let (r, g, b) = if hp < 1.0 {
        (chroma, second, 0.0)
    } else if hp < 2.0 {
        (second, chroma, 0.0)
    } else if hp < 3.0 {
        (0.0, chroma, second)
    } else if hp < 4.0 {
        (0.0, second, chroma)
    } else if hp < 5.0 {
        (second, 0.0, chroma)
    } else {
        (chroma, 0.0, second)
    };
    let match_lightness = lightness - chroma / 2.0;
    let byte = |value: f64| -> u8 {
        ((value + match_lightness) * 255.0).round().clamp(0.0, 255.0) as u8
    };
    (byte(r), byte(g), byte(b))
}

/// Акцент для курсора в сайтах: тот же цвет, что видит пользователь в теме.
/// При «как сейчас» (и для битых значений) возвращаем исходный hex как есть.
pub fn accent_with_saturation(accent: &str, saturation: Option<u8>) -> String {
    let Some(percent) = saturation else {
        return accent.to_string();
    };
    if percent >= 100 {
        return accent.to_string();
    }
    let raw = accent.trim().trim_start_matches('#');
    if raw.len() != 6 || !raw.chars().all(|c| c.is_ascii_hexdigit()) {
        return accent.to_string();
    }
    let hex_byte = |from: usize, to: usize| -> Result<f64, ()> {
        u8::from_str_radix(&raw[from..to], 16)
            .map(|v| v as f64 / 255.0)
            .map_err(|_| ())
    };
    let (Ok(r), Ok(g), Ok(b)) = (hex_byte(0, 2), hex_byte(2, 4), hex_byte(4, 6)) else {
        return accent.to_string();
    };

    let max = r.max(g).max(b);
    let min = r.min(g).min(b);
    let lightness = (max + min) / 2.0;
    let delta = max - min;
    if delta == 0.0 {
        return accent.to_string();
    }
    let mut saturation_hsl = if lightness > 0.5 {
        delta / (2.0 - max - min)
    } else {
        delta / (max + min)
    };
    saturation_hsl *= percent as f64 / 100.0;
    let hue = if max == r {
        (g - b) / delta + if g < b { 6.0 } else { 0.0 }
    } else if max == g {
        (b - r) / delta + 2.0
    } else {
        (r - g) / delta + 4.0
    };

    let (red, green, blue) = hsl_to_rgb(hue / 6.0, saturation_hsl, lightness);
    format!("#{red:02x}{green:02x}{blue:02x}")
}

impl Default for Settings {
    fn default() -> Self {
        Self {
            scheme: "dark".into(),
            accent: Some("#6a4bd8".into()),
            search_engine: "yandex".into(),
            download_path: None,
            ui_theme: UiTheme::default(),
            dialog_style: "pattern".into(),
            language: "ru".into(),
            saturation: None,
            cursor_preset: "ghost".into(),
            sounds: false,
            app_icon: "default".into(),
        }
    }
}

/// Вкладка + «рантайм»-данные, которые не уходят на фронтенд.
#[derive(Debug, Clone)]
pub struct TabRuntime {
    pub info: TabInfo,
    /// Метка дочернего webview (например `tab_7`).
    pub label: String,
    /// История переходов для кнопок «назад/вперёд».
    pub history: Vec<String>,
    /// Индекс текущей страницы в `history`.
    pub history_index: usize,
}

#[derive(Debug)]
pub struct BrowserState {
    pub tabs: Vec<TabRuntime>,
    pub active_id: Option<u32>,
    pub next_id: u32,
    pub settings: Settings,
    pub settings_open: bool,
    pub downloads_open: bool,
    pub ui_editor_open: bool,
    /// Высота хрома в логических пикселях — чтобы сдвинуть webview вниз.
    pub chrome_height: f64,
    /// Реальные загрузки WebView2 (не уходят в `public_state`).
    pub downloads: Vec<DownloadItem>,
    /// Текущий зум (1.0 = 100%).
    pub zoom: f64,
    /// URL и заголовки закрытых вкладок для Ctrl+Shift+T (последние сверху).
    pub closed_tabs: Vec<(String, String)>,
}

impl Default for BrowserState {
    fn default() -> Self {
        Self {
            tabs: Vec::new(),
            active_id: None,
            next_id: 1,
            settings: Settings::default(),
            settings_open: false,
            downloads_open: false,
            ui_editor_open: false,
            chrome_height: 104.0,
            downloads: Vec::new(),
            zoom: 1.0,
            closed_tabs: Vec::new(),
        }
    }
}

/// Акцент Windows из реестра: DWM хранит `AccentColor` как `0xAABBGGRR`.
pub fn system_accent() -> String {
    #[cfg(windows)]
    {
        use std::process::Command;
        if let Ok(output) = Command::new("reg")
            .args([
                "query",
                r"HKCU\Software\Microsoft\Windows\DWM",
                "/v",
                "AccentColor",
            ])
            .output()
        {
            let text = String::from_utf8_lossy(&output.stdout);
            if let Some(token) = text.split_whitespace().find(|t| t.starts_with("0x")) {
                if let Ok(value) = u32::from_str_radix(token.trim_start_matches("0x"), 16) {
                    let r = value & 0xff;
                    let g = (value >> 8) & 0xff;
                    let b = (value >> 16) & 0xff;
                    return format!("#{r:02x}{g:02x}{b:02x}");
                }
            }
        }
    }
    "#6a4bd8".into()
}

/// Настоящее состояние окна: `public_state()` его не знает, а WebView2-хром
/// должен показывать актуальные «развернуть/восстановить» и fullscreen.
pub fn window_info_from_app(app: &tauri::AppHandle) -> WindowInfo {
    let win = app.get_webview_window("main");
    WindowInfo {
        maximized: win.as_ref().and_then(|w| w.is_maximized().ok()).unwrap_or(false),
        fullscreen: win.as_ref().and_then(|w| w.is_fullscreen().ok()).unwrap_or(false),
        focused: win.as_ref().and_then(|w| w.is_focused().ok()).unwrap_or(true),
    }
}

fn settings_path(app: &tauri::AppHandle) -> Option<PathBuf> {
    app.path().app_config_dir().ok().map(|dir| dir.join("settings.json"))
}

/// Настройки живут в `%APPDATA%\dev.ghoststar.browser\settings.json`.
pub fn load_settings(app: &tauri::AppHandle) -> Settings {
    let Some(path) = settings_path(app) else {
        return Settings::default();
    };
    let mut settings: Settings = std::fs::read_to_string(path)
        .ok()
        .and_then(|text| serde_json::from_str::<Settings>(&text).ok())
        .unwrap_or_default();
    settings.dialog_style = normalize_dialog_style(&settings.dialog_style).into();
    settings.language = normalize_language(&settings.language).into();
    settings.saturation = settings.saturation.filter(|value| *value <= 100);
    settings.cursor_preset = normalize_cursor_preset(&settings.cursor_preset).into();
    settings.app_icon = normalize_app_icon(&settings.app_icon).into();
    settings
}

pub fn save_settings(app: &tauri::AppHandle, settings: &Settings) {
    let Some(path) = settings_path(app) else {
        return;
    };
    if let Some(dir) = path.parent() {
        let _ = std::fs::create_dir_all(dir);
    }
    if let Ok(text) = serde_json::to_string_pretty(settings) {
        let _ = std::fs::write(path, text);
    }
}

impl BrowserState {
    pub fn find(&self, id: u32) -> Option<&TabRuntime> {
        self.tabs.iter().find(|t| t.info.id == id)
    }

    pub fn find_mut(&mut self, id: u32) -> Option<&mut TabRuntime> {
        self.tabs.iter_mut().find(|t| t.info.id == id)
    }

    /// Собирает публичную копию для фронтенда.
    pub fn public_state(&self) -> AppState {
        let accent = self.settings.accent.clone().unwrap_or_else(system_accent);
        AppState {
            tabs: self.tabs.iter().map(|t| t.info.clone()).collect(),
            active_id: self.active_id,
            theme: ThemeInfo {
                scheme: self.settings.scheme.clone(),
                accent,
                motion: "expressive".into(),
            },
            window: WindowInfo {
                maximized: false,
                fullscreen: false,
                focused: true,
            },
            search_engine: self.settings.search_engine.clone(),
            settings_open: self.settings_open,
            downloads_open: self.downloads_open,
            ui_editor_open: self.ui_editor_open,
        }
    }
}
