/**
 * Мост GhostApi -> Tauri.
 *
 * Старый рендерер из Electron ждёт `window.ghost`. Здесь мы собираем этот же
 * объект, но вместо IPC Electron используем invoke/listen из @tauri-apps/api.
 * Файл импортируется самым первым в main.ts, поэтому `window.ghost` уже готов,
 * когда рендерер читает его на верхнем уровне модуля.
 *
 * Если открыть страницу в обычном браузере (npm run dev), включается рабочий
 * mock — интерфейс можно проверять и без запуска Rust.
 */
import { invoke } from '@tauri-apps/api/core'
import { listen } from '@tauri-apps/api/event'
import { getVersion } from '@tauri-apps/api/app'
import { getCurrentWindow } from '@tauri-apps/api/window'
import type {
  AppState,
  AppIconId,
  CursorPresetId,
  DialogStyle,
  DownloadItem,
  GhostApi,
  LanguageId,
  SearchEngineId,
  SettingsPatch,
  SettingsSync,
  TabInfo,
  UiPreset,
} from '../../shared/types'
import { normalizeCursorPreset } from './cursor'
import { emptyPreset, sanitizePreset } from './ui-editor/preset'
import { normalizeSaturation } from './theme-palette'

const isTauri = '__TAURI_INTERNALS__' in window

type MockSettings = {
  scheme: 'auto' | 'light' | 'dark'
  accent: string | null
  searchEngine: 'yandex' | 'google' | 'duckduckgo' | 'bing'
  downloadPath: string | null
  dialogStyle: DialogStyle
  language: LanguageId
  saturation: number | null
  cursorPreset: CursorPresetId
  sounds: boolean
  appIcon: AppIconId
}

const MOCK_SETTINGS_KEY = 'ghoststar:mock-settings'
const MOCK_UI_THEME_KEY = 'ghostmaterial:ui-theme'
const MOCK_CUSTOM_ICON_KEY = 'ghoststar:mock-custom-icon'

const uiThemeListeners = new Set<(preset: UiPreset) => void>()

function loadMockUiTheme(): UiPreset {
  try {
    const raw = localStorage.getItem(MOCK_UI_THEME_KEY)
    return raw ? sanitizePreset(JSON.parse(raw)) : emptyPreset()
  } catch {
    return emptyPreset()
  }
}

let mockUiTheme = loadMockUiTheme()

function notifyUiTheme(preset: UiPreset): void {
  for (const cb of uiThemeListeners) cb(preset)
}

function notifySettingsSync(settings: SettingsSync): void {
  for (const cb of settingsListeners) cb(settings)
}

function resolveMockScheme(scheme: MockSettings['scheme']): 'dark' | 'light' {
  if (scheme !== 'auto') return scheme
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
}

// В Tauri настройки хранятся в settings.json. В предпросмотре используем
// localStorage, чтобы после F5 не сбрасывались тема, акцент и поисковик.
function loadMockSettings(): MockSettings {
  const fallback: MockSettings = {
    scheme: 'dark',
    accent: '#6a4bd8',
    searchEngine: 'yandex',
    downloadPath: null,
    dialogStyle: 'pattern',
    language: 'ru',
    saturation: null,
    cursorPreset: 'ghost',
    sounds: false,
    appIcon: 'default',
  }
  try {
    const raw = localStorage.getItem(MOCK_SETTINGS_KEY)
    if (!raw) return fallback
    const saved = JSON.parse(raw) as Partial<MockSettings>
    return {
      scheme:
        saved.scheme === 'auto' || saved.scheme === 'light' || saved.scheme === 'dark'
          ? saved.scheme
          : fallback.scheme,
      accent:
        saved.accent === null ||
        (typeof saved.accent === 'string' && /^#[0-9a-f]{6}$/i.test(saved.accent))
          ? saved.accent
          : fallback.accent,
      searchEngine:
        saved.searchEngine === 'google' ||
        saved.searchEngine === 'yandex' ||
        saved.searchEngine === 'duckduckgo' ||
        saved.searchEngine === 'bing'
          ? saved.searchEngine
          : fallback.searchEngine,
      downloadPath: typeof saved.downloadPath === 'string' ? saved.downloadPath : null,
      dialogStyle:
        saved.dialogStyle === 'pattern' ||
        saved.dialogStyle === 'fullscreen' ||
        saved.dialogStyle === 'panel'
          ? saved.dialogStyle
          : fallback.dialogStyle,
      language: (['ru', 'en', 'zh', 'tr', 'fr', 'de', 'es', 'ja'] as string[]).includes(
        saved.language as string,
      )
        ? (saved.language as LanguageId)
        : fallback.language,
      saturation: normalizeSaturation(saved.saturation),
      cursorPreset: normalizeCursorPreset(saved.cursorPreset),
      sounds: typeof saved.sounds === 'boolean' ? saved.sounds : fallback.sounds,
      appIcon: normalizeAppIcon(saved.appIcon),
    }
  } catch {
    return fallback
  }
}

const APP_ICON_IDS: AppIconId[] = [
  'default', 'custom', 'classic', 'darkEdge', 'cyberGlow', 'materialLight', 'minimal',
  'purpleClassic', 'monochrome', 'classicRed', 'neon', 'cosmicOrbit',
  'aquaWave', 'armorPlate', 'pixel', 'lineArt', 'voidMatrix',
]
function normalizeAppIcon(value: unknown): AppIconId {
  return APP_ICON_IDS.find((id) => id === value) ?? 'default'
}

function saveMockSettings(): void {
  try {
    localStorage.setItem(MOCK_SETTINGS_KEY, JSON.stringify(mockSettings))
  } catch {
    /* приватный режим — просто живём без сохранения */
  }
}

const mockSettings = loadMockSettings()

const mockState: AppState = {
  tabs: [
    {
      id: 1,
      title: 'Новая вкладка',
      url: '',
      displayUrl: '',
      favicon: null,
      loading: false,
      canGoBack: false,
      canGoForward: false,
      isNewTab: true,
      audible: false,
      error: null,
    },
  ],
  activeId: 1,
  theme: {
    scheme: resolveMockScheme(mockSettings.scheme),
    accent: mockSettings.accent ?? '#6a4bd8',
    motion: 'expressive',
  },
  window: { maximized: false, fullscreen: false, focused: true },
  searchEngine: mockSettings.searchEngine,
  settingsOpen: false,
  downloadsOpen: false,
  uiEditorOpen: false,
}

const mockHistories = new Map<number, { list: string[]; index: number }>()
const mockClosedTabs: Array<{ url: string; title: string }> = []
let mockNextId = 2

// Стартовая вкладка создана статически — история для неё тоже нужна, иначе
// переходы из адресной строки и кнопки «назад» молча не работали.
mockHistories.set(1, { list: [''], index: 0 })

// ── Загрузки ────────────────────────────────────────────────────────────────
// Реальные загрузки присылает Rust (WebView2), демо-загрузки живут здесь.
const simulatedDownloads: DownloadItem[] = []
let realDownloads: DownloadItem[] = []
const downloadTimers = new Map<string, number>()
const downloadListeners = new Set<(items: DownloadItem[]) => void>()
let simNextId = 1

function downloadSnapshot(): DownloadItem[] {
  const real = realDownloads.filter((d) => !simulatedDownloads.some((s) => s.id === d.id))
  return [...real, ...simulatedDownloads].map((d) => ({ ...d }))
}

function emitDownloads(): void {
  const snapshot = downloadSnapshot()
  for (const cb of downloadListeners) cb(snapshot)
}

function stopDownloadTimer(id: string): void {
  const timer = downloadTimers.get(id)
  if (timer !== undefined) {
    window.clearInterval(timer)
    downloadTimers.delete(id)
  }
}

function startDemoDownload(filename?: string, url?: string): DownloadItem {
  const name = filename?.trim() || `ghost-file-${simNextId}.zip`
  const target = url?.trim() || `https://example.com/${encodeURIComponent(name)}`
  const total = 6_000_000 + Math.floor(Math.random() * 18_000_000)
  const item: DownloadItem = {
    id: `demo-${simNextId++}`,
    filename: name,
    url: target,
    savePath: mockSettings.downloadPath ?? 'C:\\Users\\User\\Downloads',
    totalBytes: total,
    receivedBytes: 0,
    state: 'in-progress',
    startTime: Date.now(),
    paused: false,
  }
  simulatedDownloads.unshift(item)
  emitDownloads()

  const timer = window.setInterval(() => {
    const current = simulatedDownloads.find((d) => d.id === item.id)
    if (!current || current.state !== 'in-progress' || current.paused) return
    const step = Math.max(80_000, Math.round(total * (0.015 + Math.random() * 0.035)))
    current.receivedBytes = Math.min(total, current.receivedBytes + step)
    if (current.receivedBytes >= total) {
      current.state = 'completed'
      current.endTime = Date.now()
      stopDownloadTimer(current.id)
      notifyToast(`Загрузка завершена: ${current.filename}`)
    }
    emitDownloads()
  }, 180)
  downloadTimers.set(item.id, timer)
  return { ...item }
}

function cloneState(): AppState {
  return {
    ...mockState,
    tabs: mockState.tabs.map((t) => ({ ...t })),
    theme: { ...mockState.theme },
    window: { ...mockState.window },
  }
}

const stateListeners = new Set<(state: AppState) => void>()
const toastListeners = new Set<(text: string) => void>()
const settingsListeners = new Set<(settings: SettingsSync) => void>()

function notifyState(): void {
  const snapshot = cloneState()
  for (const cb of stateListeners) cb(snapshot)
}

function notifyToast(text: string): void {
  for (const cb of toastListeners) cb(text)
}

function mockNormalize(raw: string): string {
  const text = raw.trim()
  if (/^https?:\/\//i.test(text) || text.startsWith('file://')) return text
  if (/^localhost(:\d+)?/i.test(text) || /^[^\s]+\.[^\s]{2,}/.test(text)) return `https://${text}`
  const q = encodeURIComponent(text)
  const engine = mockSettings.searchEngine
  if (engine === 'google') return `https://www.google.com/search?q=${q}`
  if (engine === 'duckduckgo') return `https://duckduckgo.com/?q=${q}`
  if (engine === 'bing') return `https://www.bing.com/search?q=${q}`
  return `https://yandex.ru/search/?text=${q}`
}

function mockCreateTab(url?: string, background?: boolean): number {
  const id = mockNextId++
  const isNewTab = !url?.trim()
  const target = isNewTab ? '' : mockNormalize(url!)
  const tab: TabInfo = {
    id,
    title: isNewTab ? 'Новая вкладка' : target,
    url: target,
    displayUrl: target,
    favicon: null,
    loading: false,
    canGoBack: false,
    canGoForward: false,
    isNewTab,
    audible: false,
    error: null,
  }
  mockState.tabs.push(tab)
  mockHistories.set(id, { list: [isNewTab ? '' : target], index: 0 })
  if (!background) mockState.activeId = id
  notifyState()
  return id
}

function mockCloseTab(id: number): void {
  const index = mockState.tabs.findIndex((t) => t.id === id)
  if (index < 0) return
  const [tab] = mockState.tabs.splice(index, 1)
  mockClosedTabs.push({ url: tab.url, title: tab.title })
  mockHistories.delete(id)
  if (mockState.activeId === id) {
    const next = mockState.tabs[Math.min(index, mockState.tabs.length - 1)]
    mockState.activeId = next?.id ?? null
  }
  if (mockState.tabs.length === 0) mockCreateTab()
  else notifyState()
}

function mockNavigate(id: number, raw: string): void {
  const tab = mockState.tabs.find((t) => t.id === id)
  const history = mockHistories.get(id)
  if (!tab || !history) return
  const target = mockNormalize(raw)
  if (history.index + 1 < history.list.length) history.list.length = history.index + 1
  history.list.push(target)
  history.index = history.list.length - 1
  tab.url = target
  tab.displayUrl = target
  tab.title = target
  tab.isNewTab = false
  tab.canGoBack = history.index > 0
  tab.canGoForward = false
  notifyState()
}

function mockNav(action: string): void {
  const id = mockState.activeId
  const tab = mockState.tabs.find((t) => t.id === id)
  const history = id === null ? undefined : mockHistories.get(id)
  if (!tab || !history) return
  if (action === 'back' || action === 'forward') {
    const next = action === 'back' ? history.index - 1 : history.index + 1
    if (next < 0 || next >= history.list.length) return
    history.index = next
    const target = history.list[next]
    tab.url = target
    tab.displayUrl = target
    tab.title = target || 'Новая вкладка'
    tab.isNewTab = !target
    tab.canGoBack = next > 0
    tab.canGoForward = next + 1 < history.list.length
    notifyState()
  } else if (action === 'home') {
    tab.url = ''
    tab.displayUrl = ''
    tab.title = 'Новая вкладка'
    tab.isNewTab = true
    notifyState()
  } else if (action === 'reload' || action === 'hard-reload') {
    // В предпросмотре страницу перезагружать не нужно.
  } else if (action === 'stop') {
    tab.loading = false
    notifyState()
  }
}

function mockCall<T>(command: string, args?: Record<string, unknown>): Promise<T> {
  let value: unknown = undefined

  switch (command) {
    case 'state':
      value = cloneState()
      break
    case 'get_settings':
      value = { ...mockSettings }
      break
    case 'apply_settings': {
      const patch = (args?.patch ?? {}) as SettingsPatch
      if (patch.scheme !== undefined) {
        mockSettings.scheme = patch.scheme
        mockState.theme.scheme = resolveMockScheme(patch.scheme)
      }
      if (patch.accent !== undefined) {
        mockSettings.accent = patch.accent
        mockState.theme.accent = patch.accent ?? '#6a4bd8'
      }
      if (patch.searchEngine !== undefined) {
        mockSettings.searchEngine = patch.searchEngine
        mockState.searchEngine = patch.searchEngine
      }
      if (patch.downloadPath !== undefined) mockSettings.downloadPath = patch.downloadPath
      if (
        patch.dialogStyle === 'pattern' ||
        patch.dialogStyle === 'fullscreen' ||
        patch.dialogStyle === 'panel'
      ) {
        mockSettings.dialogStyle = patch.dialogStyle
      }
      if (patch.language) mockSettings.language = patch.language
      if (patch.saturation !== undefined) {
        mockSettings.saturation = normalizeSaturation(patch.saturation)
      }
      if (patch.cursorPreset !== undefined) {
        mockSettings.cursorPreset = normalizeCursorPreset(patch.cursorPreset)
      }
      if (patch.sounds !== undefined) mockSettings.sounds = !!patch.sounds
      if (patch.appIcon !== undefined) mockSettings.appIcon = normalizeAppIcon(patch.appIcon)
      saveMockSettings()
      value = cloneState()
      notifyState()
      notifySettingsSync({
        scheme: mockSettings.scheme,
        accent: mockSettings.accent,
        searchEngine: mockSettings.searchEngine,
        language: mockSettings.language,
        saturation: mockSettings.saturation,
        cursorPreset: mockSettings.cursorPreset,
        sounds: mockSettings.sounds,
      })
      break
    }
    case 'start_download':
      value = startDemoDownload(args?.filename as string | undefined, args?.url as string | undefined)
      break
    case 'get_downloads':
      value = downloadSnapshot()
      break
    case 'create_tab':
      value = mockCreateTab(args?.url as string | undefined, !!args?.background)
      break
    case 'close_tab':
      mockCloseTab(args?.id as number)
      break
    case 'select_tab': {
      const id = args?.id as number
      if (mockState.tabs.some((t) => t.id === id)) {
        mockState.activeId = id
        notifyState()
      }
      break
    }
    case 'reopen_tab': {
      const entry = mockClosedTabs.pop()
      if (!entry) return Promise.reject(new Error('Нет закрытых вкладок'))
      mockCreateTab(entry.url)
      notifyToast('Вкладка восстановлена')
      break
    }
    case 'navigate':
      mockNavigate(args?.id as number, args?.url as string)
      break
    case 'nav':
      mockNav(String(args?.action))
      break
    case 'set_overlay':
      mockState.settingsOpen = !!args?.open
      if (args?.open) {
        mockState.downloadsOpen = false
        mockState.uiEditorOpen = false
      }
      notifyState()
      break
    case 'set_downloads':
      mockState.downloadsOpen = !!args?.open
      if (args?.open) {
        mockState.settingsOpen = false
        mockState.uiEditorOpen = false
      }
      notifyState()
      break
    case 'set_ui_editor':
      mockState.uiEditorOpen = !!args?.open
      if (args?.open) {
        mockState.settingsOpen = false
        mockState.downloadsOpen = false
      }
      notifyState()
      break
    case 'get_ui_theme':
      mockUiTheme = loadMockUiTheme()
      value = mockUiTheme
      break
    case 'set_ui_theme':
      mockUiTheme = sanitizePreset(args?.preset)
      try {
        localStorage.setItem(MOCK_UI_THEME_KEY, JSON.stringify(mockUiTheme))
      } catch {
        /* приватный режим */
      }
      notifyUiTheme(mockUiTheme)
      value = mockUiTheme
      break
    case 'reset_ui_theme':
      mockUiTheme = emptyPreset()
      try {
        localStorage.removeItem(MOCK_UI_THEME_KEY)
      } catch {
        /* приватный режим */
      }
      notifyUiTheme(mockUiTheme)
      value = mockUiTheme
      break

    case 'get_custom_app_icon':
      try { value = localStorage.getItem(MOCK_CUSTOM_ICON_KEY) } catch { value = null }
      break
    case 'save_custom_app_icon': {
      const dataUrl = String(args?.dataUrl ?? args?.data_url ?? '')
      try { localStorage.setItem(MOCK_CUSTOM_ICON_KEY, dataUrl) } catch { /* ignore */ }
      mockSettings.appIcon = 'custom'
      saveMockSettings()
      notifySettingsSync({
        scheme: mockSettings.scheme,
        accent: mockSettings.accent,
        searchEngine: mockSettings.searchEngine,
        language: mockSettings.language,
        saturation: mockSettings.saturation,
        cursorPreset: mockSettings.cursorPreset,
        sounds: mockSettings.sounds,
      })
      value = { ...mockSettings }
      break
    }
    case 'open_downloads_folder':
      value = mockSettings.downloadPath ?? 'C:\\Users\\User\\Downloads'
      break
    case 'choose_download_dir':
      value = null
      break
    case 'clear_downloads':
      for (const id of [...downloadTimers.keys()]) stopDownloadTimer(id)
      simulatedDownloads.length = 0
      emitDownloads()
      break
    case 'remove_download': {
      const id = String(args?.id ?? '')
      stopDownloadTimer(id)
      const index = simulatedDownloads.findIndex((d) => d.id === id)
      if (index >= 0) simulatedDownloads.splice(index, 1)
      emitDownloads()
      break
    }
    case 'pause_download': {
      const d = simulatedDownloads.find((item) => item.id === args?.id)
      if (d && d.state === 'in-progress') d.paused = true
      emitDownloads()
      break
    }
    case 'resume_download': {
      const d = simulatedDownloads.find((item) => item.id === args?.id)
      if (d && d.state === 'in-progress') d.paused = false
      emitDownloads()
      break
    }
    case 'cancel_download': {
      const d = simulatedDownloads.find((item) => item.id === args?.id)
      if (d && d.state === 'in-progress') {
        d.state = 'cancelled'
        d.paused = false
        stopDownloadTimer(d.id)
      }
      emitDownloads()
      break
    }
    case 'open_download': {
      const d = simulatedDownloads.find((item) => item.id === args?.id)
      if (d) notifyToast(`Демо-файл: ${d.filename}`)
      break
    }
    case 'show_download_in_folder': {
      const d = simulatedDownloads.find((item) => item.id === args?.id)
      if (d) notifyToast(`Папка загрузок: ${d.savePath}`)
      break
    }
    default:
      // set_zoom / toggle_devtools / set_chrome_height — в предпросмотре no-op.
      break
  }
  return Promise.resolve(value as T)
}

const call = <T>(command: string, args?: Record<string, unknown>): Promise<T> =>
  isTauri ? invoke<T>(command, args) : mockCall<T>(command, args)

const win = isTauri ? getCurrentWindow() : null

const unlisten: Array<() => void> = []

/**
 * Регистрирует слушателя сразу и запоминает отписку. Если `off()` вызвать до
 * того, как `listen()` вернётся, мы всё равно отпишемся — раньше здесь была
 * гонка: слушатель оставался навсегда.
 */
function on<T>(event: string, cb: (payload: T) => void): () => void {
  if (!isTauri) return () => {}
  let dispose: (() => void) | null = null
  let disposed = false
  void listen<T>(event, (e) => {
    if (!disposed) cb(e.payload)
  }).then(
    (fn) => {
      if (disposed) fn()
      else dispose = fn
    },
    () => {
      /* Tauri мог закрыться — слушатель просто не нужен */
    },
  )
  const off = () => {
    if (disposed) return
    disposed = true
    dispose?.()
  }
  unlisten.push(off)
  return off
}

/** Подтянуть состояние после действия с окном (Tauri не шлёт событие сам). */
async function refreshState(): Promise<void> {
  try {
    const next = await call<AppState>('state')
    for (const cb of stateListeners) cb(next)
  } catch {
    /* окно могло закрыться */
  }
}

// Настоящие загрузки приходят из Rust, демо — остаются локальными.
if (isTauri) {
  on<DownloadItem[]>('ghost://downloads-updated', (items) => {
    realDownloads = items
    emitDownloads()
  })
  void call<DownloadItem[]>('get_downloads').then(
    (items) => {
      realDownloads = items
      emitDownloads()
    },
    () => {
      /* загрузки пока недоступны — покажем только демо */
    },
  )
}

const isDemoDownload = (id: string): boolean => id.startsWith('demo-')

/** Действие над загрузкой уходит в Rust или остаётся в демо-движке. */
const downloadAction = <T>(command: string, id: string): Promise<T> =>
  isDemoDownload(id) ? mockCall<T>(command, { id }) : call<T>(command, { id })

const bridge: GhostApi = {
  platform: isTauri ? 'tauri-windows' : 'browser-preview',
  version: '0.1.0',
  chromeVersion: 'WebView2',

  invoke: {
    state: () => call<AppState>('state'),
    createTab: (url?: string, background?: boolean) =>
      call<number>('create_tab', { url: url ?? null, background: background ?? false }),
    closeTab: (id: number) => call<void>('close_tab', { id }),
    selectTab: (id: number) => call<void>('select_tab', { id }),
    reopenTab: () => call<void>('reopen_tab'),
    navigate: (id: number, url: string) => call<void>('navigate', { id, url }),
    nav: (action) => call<void>('nav', { action }),
    // Rust ждёт строку: "0.1" / "-0.1" / "reset". Число отклоняется Tauri.
    setZoom: (delta: number | 'reset') => call<void>('set_zoom', { delta: String(delta) }),
    toggleDevTools: () => call<void>('toggle_devtools'),
    setOverlay: (open: boolean) => call<void>('set_overlay', { open }),
    setDownloads: (open: boolean) => call<void>('set_downloads', { open }),
    setUiEditor: (open: boolean) => call<void>('set_ui_editor', { open }),
    applySettings: (patch: SettingsPatch) => call<AppState>('apply_settings', { patch }),
    getSettings: () =>
      call<{
        scheme: 'auto' | 'light' | 'dark'
        accent: string | null
        searchEngine: 'yandex' | 'google' | 'duckduckgo' | 'bing'
        downloadPath: string | null
        dialogStyle: DialogStyle
        language: LanguageId
        saturation: number | null
        cursorPreset: CursorPresetId
        sounds: boolean
        appIcon: AppIconId
      }>('get_settings'),
    // Кнопка «демо» остаётся локальной; реальные файлы приходят из WebView2.
    startDownload: (filename, url) =>
      mockCall<DownloadItem>('start_download', { filename: filename ?? null, url: url ?? null }),
    getDownloads: async () => {
      if (isTauri) {
        try {
          realDownloads = await call<DownloadItem[]>('get_downloads')
        } catch {
          /* оставляем прежний список */
        }
        emitDownloads()
      }
      return downloadSnapshot()
    },
    clearDownloads: async () => {
      if (isTauri) {
        try {
          await call<void>('clear_downloads')
        } catch {
          /* real список всё равно очистим локально */
        }
        realDownloads = []
      }
      await mockCall<void>('clear_downloads')
      emitDownloads()
    },
    removeDownload: (id: string) => downloadAction<void>('remove_download', id),
    openDownload: (id: string) => downloadAction<void>('open_download', id),
    showDownloadInFolder: (id: string) => downloadAction<void>('show_download_in_folder', id),
    pauseDownload: (id: string) => downloadAction<void>('pause_download', id),
    resumeDownload: (id: string) => downloadAction<void>('resume_download', id),
    cancelDownload: (id: string) => downloadAction<void>('cancel_download', id),
    chooseDownloadDir: () => call<string | null>('choose_download_dir'),
    openDownloadsFolder: () => call<string>('open_downloads_folder'),
    capturePage: () => (isTauri ? call<string>('capture_page') : Promise.resolve('')),
    getUiTheme: () => call<UiPreset>('get_ui_theme'),
    setUiTheme: (preset: UiPreset) => call<UiPreset>('set_ui_theme', { preset }),
    resetUiTheme: () => call<UiPreset>('reset_ui_theme'),
    getCustomAppIcon: () => call<string | null>('get_custom_app_icon'),
    saveCustomAppIcon: (dataUrl: string) => call<{
      scheme: 'auto' | 'light' | 'dark'
      accent: string | null
      searchEngine: SearchEngineId
      downloadPath: string | null
      dialogStyle: DialogStyle
      language: LanguageId
      saturation: number | null
      cursorPreset: CursorPresetId
      sounds: boolean
      appIcon: AppIconId
    }>('save_custom_app_icon', { dataUrl }),
    notifyWallpaper: (action) =>
      isTauri ? call<void>('notify_wallpaper', { action }) : Promise.resolve(),
  },

  window: {
    minimize: () => void win?.minimize(),
    toggleMaximize: () => {
      void win?.toggleMaximize().then(() => refreshState())
    },
    close: () => void win?.close(),
    toggleFullscreen: () => {
      void win?.isFullscreen().then((full) => void win.setFullscreen(!full).then(() => refreshState()))
    },
  },

  setChromeHeight: (height: number) => {
    void call<void>('set_chrome_height', { height })
  },

  onState: (cb) => {
    stateListeners.add(cb)
    const off = on<AppState>('ghost://state', cb)
    return () => {
      stateListeners.delete(cb)
      off()
    }
  },
  // Эти события пока не отправляются Rust: оставляем API, но без лишних
  // подписок в браузерном предпросмотре.
  onFocusOmnibox: (cb) => isTauri ? on<void>('ghost://focus-omnibox', cb) : () => {},
  onCloseOverlay: (cb) => isTauri ? on<void>('ghost://close-overlay', cb) : () => {},
  onCloseDownloads: (cb) => isTauri ? on<void>('ghost://close-downloads', cb) : () => {},
  onToast: (cb) => {
    toastListeners.add(cb)
    return isTauri ? on<string>('ghost://toast', cb) : () => {}
  },
  onDownloadsUpdated: (cb) => {
    downloadListeners.add(cb)
    return () => downloadListeners.delete(cb)
  },
  onSettings: (cb) => {
    settingsListeners.add(cb)
    const off = on<SettingsSync>('ghost://settings', cb)
    return () => {
      settingsListeners.delete(cb)
      off()
    }
  },
  onUiTheme: (cb) => {
    uiThemeListeners.add(cb)
    const off = on<UiPreset>('ghost://ui-theme', cb)
    return () => {
      uiThemeListeners.delete(cb)
      off()
    }
  },
}

window.ghost = bridge

void (async () => {
  if (!isTauri) {
    bridge.chromeVersion = 'браузерный предпросмотр'
    return
  }
  try {
    bridge.version = await getVersion()
  } catch {
    /* оставляем дефолт */
  }
  const ua = navigator.userAgent
  const m = /(?:Chrome|Edg)\/([\d.]+)/.exec(ua)
  bridge.chromeVersion = m ? `WebView2 · Chromium ${m[1]}` : 'WebView2'
})()

window.addEventListener('pagehide', () => {
  for (const off of unlisten) off()
  stateListeners.clear()
  toastListeners.clear()
  downloadListeners.clear()
  settingsListeners.clear()
})

declare global {
  interface Window {
    ghost: GhostApi
  }
}
