import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { defineConfig } from 'vite'

const root = dirname(fileURLToPath(import.meta.url))

export default defineConfig({
  clearScreen: false,
  server: {
    host: '127.0.0.1',
    port: 1434,
    strictPort: true,
    hmr: {
      port: 1435,
    },
    // Cargo перезаписывает .exe в target во время dev-сборки — не следим за ним,
    // иначе Vite падает с EBUSY и Tauri считает, что фронтенд умер.
    watch: {
      ignored: ['**/src-tauri/target/**'],
    },
  },
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    chunkSizeWarningLimit: 1500,
    rollupOptions: {
      // «Новая вкладка» — отдельная страница внутри дочернего webview.
      input: {
        index: resolve(root, 'index.html'),
        newtab: resolve(root, 'newtab.html'),
      },
    },
  },
})
