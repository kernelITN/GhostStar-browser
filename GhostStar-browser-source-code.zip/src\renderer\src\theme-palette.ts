/**
 * Один акцентный цвет на весь интерфейс.
 *
 * md-theme в варианте `expressive` берёт акцент только для primary, а
 * secondary/tertiary красит в другие оттенки (например, зелёный). Нам нужно,
 * чтобы вкладки, чипы, кнопки и фон использовали один и тот же цвет — поэтому
 * подменяем роли secondary/tertiary значениями primary из той же схемы.
 */
import { generateM3Scheme } from '@materialwebunofficial/md3e-web/theme'

const ROLE_MAP: Record<string, string> = {
  secondary: 'primary',
  'on-secondary': 'on-primary',
  'secondary-container': 'primary-container',
  'on-secondary-container': 'on-primary-container',
  'secondary-fixed': 'primary-fixed',
  'secondary-fixed-dim': 'primary-fixed-dim',
  'on-secondary-fixed': 'on-primary-fixed',
  'on-secondary-fixed-variant': 'on-primary-fixed-variant',
  tertiary: 'primary',
  'on-tertiary': 'on-primary',
  'tertiary-container': 'primary-container',
  'on-tertiary-container': 'on-primary-container',
  'tertiary-fixed': 'primary-fixed',
  'tertiary-fixed-dim': 'primary-fixed-dim',
  'on-tertiary-fixed': 'on-primary-fixed',
  'on-tertiary-fixed-variant': 'on-primary-fixed-variant',
}

/** Значение для атрибута `custom-palette` у `<md-theme>`. */
export function singleAccentPalette(seed: string, dark: boolean): Record<string, string> {
  const tokens = generateM3Scheme(seed, dark, 'expressive')
  const palette: Record<string, string> = {}
  for (const [role, source] of Object.entries(ROLE_MAP)) {
    const color = tokens[`--md-sys-color-${source}`]
    if (color) palette[role] = color
  }
  return palette
}

/**
 * Насыщенность акцента: `null` = «как сейчас», число 0–100 = доля исходной
 * насыщенности. 100 и неверные значения тоже возвращают исходный цвет —
 * старые настройки и битый URL никогда не меняют палитру.
 */
export function normalizeSaturation(value: unknown): number | null {
  if (value === null || value === undefined || value === '') return null
  const num = Number(value)
  if (!Number.isFinite(num)) return null
  if (num < 0 || num > 100) return null
  return Math.round(num)
}

function hexToRgb(hex: string): [number, number, number] {
  const value = Number.parseInt(hex.slice(1), 16)
  return [(value >> 16) & 255, (value >> 8) & 255, value & 255]
}

function rgbToHsl(r: number, g: number, b: number): [number, number, number] {
  const rn = r / 255
  const gn = g / 255
  const bn = b / 255
  const max = Math.max(rn, gn, bn)
  const min = Math.min(rn, gn, bn)
  const lightness = (max + min) / 2
  const delta = max - min
  if (delta === 0) return [0, 0, lightness]

  const saturation = lightness > 0.5 ? delta / (2 - max - min) : delta / (max + min)
  let hue: number
  if (max === rn) hue = (gn - bn) / delta + (gn < bn ? 6 : 0)
  else if (max === gn) hue = (bn - rn) / delta + 2
  else hue = (rn - gn) / delta + 4
  return [hue / 6, saturation, lightness]
}

function hslToHex(hue: number, saturation: number, lightness: number): string {
  const chroma = (1 - Math.abs(2 * lightness - 1)) * saturation
  const hp = hue * 6
  const second = chroma * (1 - Math.abs((hp % 2) - 1))
  let parts: [number, number, number]
  if (hp < 1) parts = [chroma, second, 0]
  else if (hp < 2) parts = [second, chroma, 0]
  else if (hp < 3) parts = [0, chroma, second]
  else if (hp < 4) parts = [0, second, chroma]
  else if (hp < 5) parts = [second, 0, chroma]
  else parts = [chroma, 0, second]

  const match = lightness - chroma / 2
  return `#${parts
    .map((part) => Math.round((part + match) * 255).toString(16).padStart(2, '0'))
    .join('')}`
}

/** Возвращает акцент с уменьшенной насыщенностью. «Как сейчас» — без изменений. */
export function adjustAccentSaturation(seed: string, saturation: number | null): string {
  const percent = normalizeSaturation(saturation)
  if (percent === null || percent === 100) return seed
  if (!/^#[0-9a-f]{6}$/i.test(seed)) return seed

  const [r, g, b] = hexToRgb(seed)
  const [hue, originalSaturation, lightness] = rgbToHsl(r, g, b)
  // Серый цвет нечего масштабировать — возвращаем исходный байт-в-байт.
  if (originalSaturation === 0) return seed
  return hslToHex(hue, originalSaturation * (percent / 100), lightness)
}
