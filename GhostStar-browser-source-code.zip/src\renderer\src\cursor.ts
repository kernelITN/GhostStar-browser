/**
 * Пять пресетов курсора в стиле Material 3 Expressive.
 *
 * SVG превращается в data: URL — так курсор рисуется браузером без картинок
 * и сразу перекрашивается, когда меняется акцент. Тот же набор пресетов
 * дублируется в CURSOR_JS (src-tauri/src/tabs.rs) для дочерних webview:
 * туда наш CSS не дотягивается. Если меняешь форму здесь — меняй и там.
 */

export const CURSOR_PRESET_IDS = ['ghost', 'classic', 'neon', 'outline', 'minimal'] as const

export type CursorPresetId = (typeof CURSOR_PRESET_IDS)[number]

const FALLBACK = '#6750a4'

/** Общая форма стрелки; у пресетов меняются только слои, размер и hotspot. */
const ARROW_D =
  'M4 2.6c-.8 0-1.4.6-1.4 1.4v20.3c0 1.1 1.3 1.7 2.1.9l4.4-4.4 4.3 8.4c.3.6 1.1.9 1.7.6l3.2-1.6c.7-.3 1-1.1.6-1.7l-4.1-8 8.7-.3c1.1 0 1.6-1.4.7-2.1L5.4 2.9c-.4-.4-.9-.3-1.4-.3Z'

/** Битые значения из settings.json не должны ломать курсор. */
export function normalizeCursorPreset(value: unknown): CursorPresetId {
  return CURSOR_PRESET_IDS.find((id) => id === value) ?? 'ghost'
}

function validHex(value: unknown): string {
  return typeof value === 'string' && /^#[0-9a-f]{6}$/i.test(value) ? value : FALLBACK
}

interface CursorShape {
  size: number
  hotspot: string
  body: string
}

function shape(preset: CursorPresetId, accent: string): CursorShape {
  const a = validHex(accent)
  switch (preset) {
    case 'classic':
      return {
        size: 30,
        hotspot: '3 2',
        body:
          `<path d="${ARROW_D}" fill="#ffffff" stroke="#1f1b25" stroke-width="2" stroke-linejoin="round"/>` +
          `<circle cx="9" cy="9" r="1.5" fill="#1f1b25" opacity="0.85"/>`,
      }
    case 'neon':
      return {
        size: 34,
        hotspot: '4 2',
        body:
          `<path d="${ARROW_D}" fill="${a}" opacity="0.22" stroke="${a}" stroke-width="6" stroke-linejoin="round"/>` +
          `<path d="${ARROW_D}" fill="${a}" stroke="#ffffff" stroke-width="1.6" stroke-linejoin="round"/>` +
          `<circle cx="9" cy="9" r="1.6" fill="#ffffff"/>`,
      }
    case 'outline':
      return {
        size: 30,
        hotspot: '3 2',
        body:
          `<path d="${ARROW_D}" fill="none" stroke="#ffffff" stroke-width="4.6" stroke-linejoin="round" opacity="0.9"/>` +
          `<path d="${ARROW_D}" fill="none" stroke="${a}" stroke-width="2.2" stroke-linejoin="round"/>` +
          `<circle cx="9" cy="9" r="1.3" fill="${a}"/>`,
      }
    case 'minimal':
      return {
        size: 24,
        hotspot: '2 1',
        body: `<path d="${ARROW_D}" fill="${a}"/>`,
      }
    case 'ghost':
    default:
      return {
        size: 30,
        hotspot: '3 2',
        body:
          `<path d="${ARROW_D}" fill="${a}" stroke="#ffffff" stroke-width="2" stroke-linejoin="round"/>` +
          `<circle cx="9" cy="9" r="1.5" fill="#ffffff" opacity="0.9"/>`,
      }
  }
}

/** CSS-значение `cursor` для превью в настройках и для основного webview. */
export function cursorCss(
  preset: CursorPresetId | null | undefined,
  accent: string | null | undefined,
): string {
  const s = shape(normalizeCursorPreset(preset), typeof accent === 'string' ? accent : FALLBACK)
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${s.size}" height="${s.size}" viewBox="-2 -2 34 34">${s.body}</svg>`
  return `url("data:image/svg+xml,${encodeURIComponent(svg)}") ${s.hotspot}, auto`
}

/** Ставит/обновляет курсор. `null` = системный акцент (в Rust он уже решён). */
export function setCursorPreset(
  preset: CursorPresetId | null | undefined,
  accent: string | null | undefined,
): void {
  let style = document.getElementById('ghost-accent-cursor') as HTMLStyleElement | null
  if (!style) {
    style = document.createElement('style')
    style.id = 'ghost-accent-cursor'
    document.head.append(style)
  }
  // Курсор текста оставляем системным: так I-beam продолжает работать.
  style.textContent = `html, body, a, button, summary, label, [role='button'] { cursor: ${cursorCss(preset, accent)} !important; }`
}

/** Оставлен для совместимости со старыми вызовами. */
export function setAccentCursor(accent: string | null | undefined): void {
  setCursorPreset('ghost', accent)
}
