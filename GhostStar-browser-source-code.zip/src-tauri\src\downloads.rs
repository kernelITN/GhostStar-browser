//! Реальные загрузки WebView2.
//!
//! Tauri отдаёт только два события: `Requested` и `Finished`. Прогресс берём
//! опросом размера файла на диске — WebView2 дописывает его по мере загрузки.

use std::{
    path::{Path, PathBuf},
    sync::{
        atomic::{AtomicU64, Ordering},
        Mutex,
    },
    time::{Duration, SystemTime, UNIX_EPOCH},
};

use tauri::{AppHandle, Emitter, Manager, Url};

use crate::state::{BrowserState, DownloadItem};

static NEXT_ID: AtomicU64 = AtomicU64::new(1);

fn now_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}

/// Обновляем список загрузок в UI.
pub fn emit(app: &AppHandle) {
    let items = {
        let st = app.state::<Mutex<BrowserState>>();
        let Ok(s) = st.lock() else { return };
        s.downloads.clone()
    };
    let _ = app.emit("ghost://downloads-updated", items);
}

fn download_dir(app: &AppHandle) -> PathBuf {
    let configured = {
        let st = app.state::<Mutex<BrowserState>>();
        st.lock()
            .map(|s| s.settings.download_path.clone())
            .unwrap_or(None)
    };
    if let Some(path) = configured.filter(|p| !p.trim().is_empty()) {
        return PathBuf::from(path);
    }
    PathBuf::from(std::env::var("USERPROFILE").unwrap_or_else(|_| "C:\\".into())).join("Downloads")
}

fn filename_from(url: &Url, destination: &Path) -> String {
    destination
        .file_name()
        .and_then(|n| n.to_str())
        .filter(|s| !s.is_empty())
        .map(str::to_string)
        .or_else(|| {
            url.path_segments()
                .and_then(|segments| segments.filter(|s| !s.is_empty()).last())
                .map(str::to_string)
        })
        .filter(|s| !s.is_empty())
        .unwrap_or_else(|| "download".to_string())
}

/// Запрашиваем Content-Length, чтобы в строке был общий размер и проценты.
fn probe_total(url: &str) -> Option<u64> {
    let output = std::process::Command::new("curl.exe")
        .args(["-L", "-I", "-s", "--max-time", "10", url])
        .output()
        .ok()?;
    for line in output.stdout.split(|&b| b == b'\n') {
        let line = String::from_utf8_lossy(line);
        let Some((name, value)) = line.split_once(':') else { continue };
        if name.trim().eq_ignore_ascii_case("content-length") {
            if let Ok(size) = value.trim().trim_matches('\r').parse::<u64>() {
                if size > 0 {
                    return Some(size);
                }
            }
        }
    }
    None
}

/// Асинхронно добавляем общий размер к уже созданной записи.
fn probe_total_async(app: AppHandle, id: String, url: String) {
    tauri::async_runtime::spawn_blocking(move || {
        let Some(total) = probe_total(&url) else { return };
        let mut changed = false;
        {
            let st = app.state::<Mutex<BrowserState>>();
            let Ok(mut s) = st.lock() else { return };
            if let Some(item) = s.downloads.iter_mut().find(|d| d.id == id) {
                if item.state == "in-progress" && item.total_bytes.is_none() {
                    item.total_bytes = Some(total);
                    changed = true;
                }
            }
        }
        if changed {
            emit(&app);
        }
    });
}

/// Пока файл качается, периодически считываем его размер и обновляем строку.
fn watch_progress(app: AppHandle, id: String, path: PathBuf) {
    tauri::async_runtime::spawn_blocking(move || {
        let mut stable_ticks = 0u32;
        // 250 мс × 2400 было всего 10 минут: медленный архив «зависал»
        // в списке. 6 часов с лихвой хватает, а Finished всё равно закроет
        // запись раньше, если WebView2 пришлёт событие.
        for _ in 0..86_400 {
            std::thread::sleep(Duration::from_millis(250));
            let mut changed = false;
            let mut finished_locally = false;
            let mut filename = String::new();
            {
                let st = app.state::<Mutex<BrowserState>>();
                let Ok(mut s) = st.lock() else { break };
                let Some(item) = s.downloads.iter_mut().find(|d| d.id == id) else {
                    break;
                };
                if item.state != "in-progress" {
                    break;
                }
                if !item.paused.unwrap_or(false) {
                    if let Ok(meta) = std::fs::metadata(&path) {
                        let size = meta.len();
                        if size != item.received_bytes {
                            item.received_bytes = size;
                            changed = true;
                            stable_ticks = 0;
                        } else if item
                            .total_bytes
                            .is_some_and(|total| total > 0 && size >= total)
                        {
                            stable_ticks += 1;
                            // Размер стоит на 100% уже 5 секунд, а Finished от
                            // WebView2 так и не пришёл — закрываем запись сами.
                            if stable_ticks >= 20 {
                                filename = item.filename.clone();
                                item.state = "completed".to_string();
                                item.end_time = Some(now_ms());
                                item.paused = Some(false);
                                finished_locally = true;
                                changed = true;
                            }
                        }
                    }
                }
            }
            if changed {
                emit(&app);
            }
            if finished_locally {
                let _ = app.emit("ghost://toast", format!("Готово: {filename}"));
                break;
            }
        }
    });
}

/// Событие `Requested`: создаём запись и подсказываем WebView2, куда сохранить файл.
pub fn requested(app: &AppHandle, url: &Url, destination: &mut PathBuf) {
    let filename = filename_from(url, destination);
    *destination = download_dir(app).join(&filename);

    let item = DownloadItem {
        id: format!("dl-{}-{}", now_ms(), NEXT_ID.fetch_add(1, Ordering::Relaxed)),
        filename,
        url: url.to_string(),
        save_path: destination.to_string_lossy().into_owned(),
        total_bytes: None,
        received_bytes: 0,
        state: "in-progress".to_string(),
        start_time: now_ms(),
        end_time: None,
        paused: Some(false),
    };

    {
        let st = app.state::<Mutex<BrowserState>>();
        if let Ok(mut s) = st.lock() {
            s.downloads.insert(0, item.clone());
        };
    }
    emit(app);
    let _ = app.emit("ghost://toast", format!("Скачивание: {}", item.filename));
    probe_total_async(app.clone(), item.id.clone(), url.to_string());
    watch_progress(app.clone(), item.id, destination.clone());
}

fn same_path(a: &str, b: &str) -> bool {
    #[cfg(windows)]
    {
        a.eq_ignore_ascii_case(b)
    }
    #[cfg(not(windows))]
    {
        a == b
    }
}

/// Событие `Finished`: закрываем запись как завершённую или прерванную.
pub fn finished(app: &AppHandle, url: &Url, path: Option<&PathBuf>, success: bool) {
    let url_text = url.to_string();
    let path_text = path.map(|p| p.to_string_lossy().into_owned());
    // WebView2 может прислать финальный URL после редиректа — сверяем ещё и
    // имя файла, иначе запись останется «в процессе» на 100%.
    let url_name = url
        .path_segments()
        .and_then(|segments| segments.filter(|s| !s.is_empty()).last())
        .map(str::to_string);
    let path_name = path
        .and_then(|p| p.file_name())
        .and_then(|n| n.to_str())
        .map(str::to_string);
    let mut changed = false;
    let mut filename = String::new();

    {
        let st = app.state::<Mutex<BrowserState>>();
        let Ok(mut s) = st.lock() else { return };
        // Точный путь надёжнее URL/имени: два файла с одинаковым именем не
        // должны «закрывать» друг друга. URL/имя — только запасной вариант,
        // когда WebView2 не прислал путь.
        let index = if let (Some(p), Some(pn)) = (path_text.as_deref(), path_name.as_deref()) {
            s.downloads
                .iter()
                .position(|d| d.state == "in-progress" && same_path(&d.save_path, p))
                .or_else(|| {
                    s.downloads.iter().position(|d| {
                        d.state == "in-progress" && d.filename.eq_ignore_ascii_case(pn)
                    })
                })
        } else {
            s.downloads.iter().position(|d| {
                d.state == "in-progress"
                    && (d.url == url_text
                        || url_name.as_ref().is_some_and(|n| n == &d.filename))
            })
        };

        if let Some(i) = index {
            let item = &mut s.downloads[i];
            filename = item.filename.clone();
            item.state = if success { "completed" } else { "interrupted" }.to_string();
            item.end_time = Some(now_ms());
            item.paused = Some(false);
            if let Some(p) = path {
                item.save_path = p.to_string_lossy().into_owned();
                if let Ok(meta) = std::fs::metadata(p) {
                    item.received_bytes = meta.len();
                    if item.total_bytes.is_none() {
                        item.total_bytes = Some(meta.len());
                    }
                }
            }
            changed = true;
        }
    }

    if changed {
        emit(app);
        let text = if success {
            format!("Готово: {filename}")
        } else {
            format!("Загрузка прервана: {filename}")
        };
        let _ = app.emit("ghost://toast", text);
    }
}
