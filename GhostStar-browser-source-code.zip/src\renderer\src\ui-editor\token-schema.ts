/**
 * Реестр токенов полного редактора UI.
 *
 * Один список — источник правды для: панели редактора, валидации пресета,
 * генерации CSS-переменных и атрибутов анимации. Добавить новый токен =
 * дописать одну строку здесь и (если нужно) подключить переменную в CSS.
 *
 * ВАЖНО: дефолты повторяют текущий дизайн 1-в-1. Волна остаётся встроенной
 * md3e-волной: amplitude=1, wavelength=40, без бликов и额外 keyframes.
 * P0 — безопасное ядро; P1-токены дописаны в конец, версия пресета не менялась.
 */
import type { UiTokenId } from '../../../shared/types'

/**
 * Стабильные id разделов. Раньше здесь были русские названия групп — они
 * показывались заголовками; теперь заголовок приходит из i18n, а id остаётся
 * внутренним и в пресет не попадает.
 */
export type UiTokenGroup = 'buttons' | 'tabs' | 'chrome' | 'windows' | 'motion'

export interface UiSectionDef {
  id: UiTokenGroup
  labelKey: string
}

/** Порябок вкладок слева — как разделы в полноэкранных настройках. */
export const UI_SECTIONS: readonly UiSectionDef[] = [
  { id: 'buttons', labelKey: 'uiSectionButtons' },
  { id: 'tabs', labelKey: 'uiSectionTabs' },
  { id: 'chrome', labelKey: 'uiSectionChrome' },
  { id: 'windows', labelKey: 'uiSectionWindows' },
  { id: 'motion', labelKey: 'uiSectionMotion' },
]

export interface UiTokenDef {
  id: UiTokenId
  label: string
  group: UiTokenGroup
  /** Значение, при котором правки нет вовсе. */
  default: number
  min: number
  max: number
  step: number
  unit: 'px' | '%' | ''
  /** Куда применять как CSS-переменную. */
  cssVar?: string
  /** Куда применять как атрибут <md-progress-indicator>. */
  waveAttr?: 'amplitude' | 'wavelength' | 'wave-speed'
  hint?: string
}

export const TOKEN_REGISTRY: readonly UiTokenDef[] = [
  // ── P0: безопасное ядро ────────────────────────────────────────────────
  {
    id: 'tabHeight',
    label: 'Высота вкладки',
    group: 'tabs',
    default: 35,
    min: 24,
    max: 56,
    step: 1,
    unit: 'px',
    cssVar: '--gb-tab-height',
  },
  {
    id: 'tabRadius',
    label: 'Скругление вкладки',
    group: 'tabs',
    default: 999,
    min: 0,
    max: 999,
    step: 1,
    unit: 'px',
    cssVar: '--gb-tab-radius',
    hint: '999 — совсем круглая «пилюля»',
  },
  {
    id: 'tabFontSize',
    label: 'Размер текста вкладки',
    group: 'tabs',
    default: 12.5,
    min: 10,
    max: 18,
    step: 0.5,
    unit: 'px',
    cssVar: '--gb-tab-font-size',
  },
  {
    id: 'toolbarHeight',
    label: 'Высота панели',
    group: 'chrome',
    default: 62,
    min: 48,
    max: 92,
    step: 1,
    unit: 'px',
    cssVar: '--gb-toolbar-height',
    hint: 'После изменения границы вкладок двигаются автоматически',
  },
  {
    id: 'toolbarGap',
    label: 'Промежуток кнопок',
    group: 'buttons',
    default: 8,
    min: 2,
    max: 28,
    step: 1,
    unit: 'px',
    cssVar: '--gb-toolbar-gap',
  },
  {
    id: 'iconButtonSize',
    label: 'Кнопки-иконки',
    group: 'buttons',
    default: 40,
    min: 28,
    max: 64,
    step: 1,
    unit: 'px',
    cssVar: '--gb-icon-button-size',
  },
  {
    id: 'brandSize',
    label: 'Логотип браузера',
    group: 'chrome',
    default: 28,
    min: 18,
    max: 48,
    step: 1,
    unit: 'px',
    cssVar: '--gb-brand-size',
  },
  {
    id: 'tileSize',
    label: 'Плитка ссылки',
    group: 'tabs',
    default: 54,
    min: 34,
    max: 84,
    step: 1,
    unit: 'px',
    cssVar: '--gb-tile-size',
    hint: 'Размер иконок на домашней странице',
  },
  {
    id: 'tileRadius',
    label: 'Скругление плитки',
    group: 'tabs',
    default: 18,
    min: 6,
    max: 36,
    step: 1,
    unit: 'px',
    cssVar: '--gb-tile-radius',
  },
  {
    id: 'dialogWidth',
    label: 'Ширина окна',
    group: 'windows',
    default: 560,
    min: 360,
    max: 980,
    step: 10,
    unit: 'px',
    cssVar: '--gb-dialog-width',
  },
  {
    id: 'dialogRadius',
    label: 'Скругление окна',
    group: 'windows',
    default: 28,
    min: 10,
    max: 48,
    step: 1,
    unit: 'px',
    cssVar: '--gb-dialog-radius',
  },
  {
    id: 'dialogPadding',
    label: 'Отступы окна',
    group: 'windows',
    default: 24,
    min: 10,
    max: 44,
    step: 1,
    unit: 'px',
    cssVar: '--gb-dialog-padding',
  },
  {
    id: 'scrimOpacity',
    label: 'Затемнение позади',
    group: 'windows',
    default: 34,
    min: 0,
    max: 85,
    step: 1,
    unit: '%',
    cssVar: '--gb-scrim-opacity',
  },
  {
    id: 'scrimBlur',
    label: 'Размытие позади',
    group: 'windows',
    default: 4,
    min: 0,
    max: 18,
    step: 1,
    unit: 'px',
    cssVar: '--gb-scrim-blur',
  },
  {
    id: 'waveAmplitude',
    label: 'Высота волны',
    group: 'motion',
    default: 1,
    min: 0,
    max: 1,
    step: 0.05,
    unit: '',
    waveAttr: 'amplitude',
    hint: '1 — как сейчас; 0 — почти ровная линия',
  },
  {
    id: 'waveLength',
    label: 'Длина волны',
    group: 'motion',
    default: 40,
    min: 8,
    max: 160,
    step: 2,
    unit: '',
    waveAttr: 'wavelength',
  },
  {
    id: 'waveSpeed',
    label: 'Скорость волны',
    group: 'motion',
    default: 40,
    min: 8,
    max: 240,
    step: 2,
    unit: '',
    waveAttr: 'wave-speed',
  },

  // ── P1: новые токены.Дефолты совпадают с текущей вёрсткой 1-в-1. ───────
  {
    id: 'tabGap',
    label: 'Промежуток вкладок',
    group: 'tabs',
    default: 6,
    min: 0,
    max: 24,
    step: 1,
    unit: 'px',
    cssVar: '--gb-tab-gap',
  },
  {
    id: 'tabPadX',
    label: 'Поля вкладки',
    group: 'tabs',
    default: 12,
    min: 2,
    max: 28,
    step: 1,
    unit: 'px',
    cssVar: '--gb-tab-pad-x',
  },
  {
    id: 'navGap',
    label: 'Промежуток иконок',
    group: 'buttons',
    default: 2,
    min: 0,
    max: 16,
    step: 1,
    unit: 'px',
    cssVar: '--gb-nav-gap',
  },
  {
    id: 'iconRadius',
    label: 'Скругление кнопок',
    group: 'buttons',
    default: 999,
    min: 0,
    max: 999,
    step: 1,
    unit: 'px',
    cssVar: '--gb-icon-radius',
    hint: '999 — круглые кнопки, как сейчас',
  },
  {
    id: 'barRadius',
    label: 'Скругление адреса',
    group: 'chrome',
    default: 999,
    min: 0,
    max: 999,
    step: 1,
    unit: 'px',
    cssVar: '--gb-bar-radius',
    hint: '999 — «пилюля», 0 — прямоугольник',
  },
  {
    id: 'tileGap',
    label: 'Промежуток плиток',
    group: 'tabs',
    default: 10,
    min: 2,
    max: 28,
    step: 1,
    unit: 'px',
    cssVar: '--gb-tile-gap',
  },
]

export const TOKEN_BY_ID: ReadonlyMap<UiTokenId, UiTokenDef> = new Map(
  TOKEN_REGISTRY.map((token) => [token.id, token]),
)

const CSS_TOKENS = TOKEN_REGISTRY.filter((t) => t.cssVar)
const WAVE_TOKENS = TOKEN_REGISTRY.filter((t) => t.waveAttr)

/** Только реально отличающиеся от дефолта значения попадают в пресет/CSS. */
export function isCustomValue(id: UiTokenId, value: number): boolean {
  const def = TOKEN_BY_ID.get(id)
  return !!def && Number.isFinite(value) && value !== def.default
}

export function formatTokenValue(token: UiTokenDef, value: number): string {
  const rounded = Math.round(value * 100) / 100
  return `${rounded}${token.unit}`
}

export function cssVarValue(id: UiTokenId): { name: string; value: string } | null {
  const def = TOKEN_BY_ID.get(id)
  if (!def?.cssVar) return null
  return { name: def.cssVar, value: formatTokenValue(def, def.default) }
}

export const CSS_TOKEN_COUNT = CSS_TOKENS.length
export const WAVE_TOKEN_COUNT = WAVE_TOKENS.length
