export type SearchEngineId = 'yandex' | 'google' | 'duckduckgo' | 'bing'

/** Пять пресетов курсора. Добавлять только в конец, старые значения читаются. */
export type CursorPresetId = 'ghost' | 'classic' | 'neon' | 'outline' | 'minimal'

/** Пресеты иконки окна/панели задач. `default` = текущая иконка приложения. */
export type AppIconId =
  | 'default'
  | 'custom'
  | 'classic'
  | 'darkEdge'
  | 'cyberGlow'
  | 'materialLight'
  | 'minimal'
  | 'purpleClassic'
  | 'monochrome'
  | 'classicRed'
  | 'neon'
  | 'cosmicOrbit'
  | 'aquaWave'
  | 'armorPlate'
  | 'pixel'
  | 'lineArt'
  | 'voidMatrix'

/** Язык интерфейса. Добавлять новые языки нужно и в renderer/src/i18n.ts. */
export type LanguageId = 'ru' | 'en' | 'zh' | 'tr' | 'fr' | 'de' | 'es' | 'ja'

/**
 * Токены полного редактора UI (P0 — безопасное ядро, P1 — расширение).
 * Новые токены добавляем только в конец: старые пресеты остаются рабочими.
 */
export type UiTokenId =
  | 'tabHeight'
  | 'tabRadius'
  | 'tabFontSize'
  | 'toolbarHeight'
  | 'toolbarGap'
  | 'iconButtonSize'
  | 'brandSize'
  | 'tileSize'
  | 'tileRadius'
  | 'dialogWidth'
  | 'dialogRadius'
  | 'dialogPadding'
  | 'scrimOpacity'
  | 'scrimBlur'
  | 'waveAmplitude'
  | 'waveLength'
  | 'waveSpeed'
  // P1: только в конец, чтобы старые пресеты version:1 читались без миграции.
  | 'tabGap'
  | 'tabPadX'
  | 'navGap'
  | 'iconRadius'
  | 'barRadius'
  | 'tileGap'

/** Только пользовательские правки. Дефолты лежат в TOKEN_REGISTRY. */
export type UiOverrides = Partial<Record<UiTokenId, number>>

/** Версионированный пресет: хранится в settings.json и синхронизируется событием. */
export interface UiPreset {
  version: 1
  overrides: UiOverrides
}

export type DownloadState = 'in-progress' | 'completed' | 'cancelled' | 'interrupted'

export interface DownloadItem {
  id: string
  filename: string
  url: string
  savePath: string
  totalBytes: number | null
  receivedBytes: number
  state: DownloadState
  startTime: number
  endTime?: number
  paused?: boolean
}

export interface TabInfo {
  id: number
  title: string
  /** Реальный URL. Для новой вкладки — пустая строка. */
  url: string
  /** URL в том виде, в котором его можно показать в адресной строке. */
  displayUrl: string
  favicon: string | null
  loading: boolean
  canGoBack: boolean
  canGoForward: boolean
  isNewTab: boolean
  audible: boolean
  error: { code: number; description: string; url: string } | null
}

export interface ThemeInfo {
  scheme: 'auto' | 'light' | 'dark'
  accent: string
  motion: 'expressive' | 'standard'
}

export interface WindowInfo {
  maximized: boolean
  fullscreen: boolean
  focused: boolean
}

export interface AppState {
  tabs: TabInfo[]
  activeId: number | null
  theme: ThemeInfo
  window: WindowInfo
  searchEngine: SearchEngineId
  settingsOpen: boolean
  downloadsOpen: boolean
  /** Отдельный флаг редактора UI, чтобы его модалка тоже скрывала вкладки. */
  uiEditorOpen: boolean
}

/** Как выглядят окна «Загрузки»/«Настройки» вместо снимка страницы. */
export type DialogStyle = 'pattern' | 'fullscreen' | 'panel'

export interface SettingsPatch {
  scheme?: 'auto' | 'light' | 'dark'
  accent?: string | null
  searchEngine?: SearchEngineId
  downloadPath?: string | null
  dialogStyle?: DialogStyle
  language?: LanguageId
  /** `null` = «как сейчас», число 0–100 = насыщенность акцента в процентах. */
  saturation?: number | null
  /** Пресет курсора; неизвестные значения нормализуются в `ghost`. */
  cursorPreset?: CursorPresetId
  /** Master-выключатель звуков. По умолчанию выключено, без автовоспроизведения. */
  sounds?: boolean
  /** Пресет иконки окна/панели задач. */
  appIcon?: AppIconId
}

/** Живое оповещение об изменении настроек (Tauri-событие и BroadcastChannel). */
export interface SettingsSync {
  scheme: 'auto' | 'light' | 'dark'
  accent: string | null
  searchEngine: SearchEngineId
  language: LanguageId
  saturation: number | null
  cursorPreset: CursorPresetId
  sounds: boolean
}

/** Живое оповещение о правках редактора UI. */
export type UiThemeSync = UiPreset

export interface GhostApi {
  platform: string
  version: string
  chromeVersion: string
  invoke: {
    state(): Promise<AppState>
    createTab(url?: string, background?: boolean): Promise<number>
    closeTab(id: number): Promise<void>
    selectTab(id: number): Promise<void>
    reopenTab(): Promise<void>
    navigate(id: number, url: string): Promise<void>
    nav(action: 'back' | 'forward' | 'reload' | 'hard-reload' | 'stop' | 'home'): Promise<void>
    setZoom(delta: number | 'reset'): Promise<void>
    toggleDevTools(): Promise<void>
    setOverlay(open: boolean): Promise<void>
    setDownloads(open: boolean): Promise<void>
    setUiEditor(open: boolean): Promise<void>
    applySettings(patch: SettingsPatch): Promise<AppState>
    getSettings(): Promise<{
      scheme: 'auto' | 'light' | 'dark'
      accent: string | null
      searchEngine: SearchEngineId
      downloadPath: string | null
      dialogStyle: DialogStyle
      language: LanguageId
      saturation: number | null
      cursorPreset: CursorPresetId
      sounds: boolean
      appIcon: AppIconId
    }>
    /** Демо-загрузка с живой анимацией прогресса. */
    startDownload(filename?: string, url?: string): Promise<DownloadItem>
    getDownloads(): Promise<DownloadItem[]>
    clearDownloads(): Promise<void>
    removeDownload(id: string): Promise<void>
    openDownload(id: string): Promise<void>
    showDownloadInFolder(id: string): Promise<void>
    pauseDownload(id: string): Promise<void>
    resumeDownload(id: string): Promise<void>
    cancelDownload(id: string): Promise<void>
    chooseDownloadDir(): Promise<string | null>
    openDownloadsFolder(): Promise<string>
    /** Снимок страницы, чтобы за модальным окном был виден сайт. */
    capturePage(): Promise<string>
    /** Полный редактор UI: разреженный пресет правок. */
    getUiTheme(): Promise<UiPreset>
    setUiTheme(preset: UiPreset): Promise<UiPreset>
    resetUiTheme(): Promise<UiPreset>
    getCustomAppIcon(): Promise<string | null>
    saveCustomAppIcon(dataUrl: string): Promise<{
      scheme: 'auto' | 'light' | 'dark'
      accent: string | null
      searchEngine: SearchEngineId
      downloadPath: string | null
      dialogStyle: DialogStyle
      language: LanguageId
      saturation: number | null
      cursorPreset: CursorPresetId
      sounds: boolean
      appIcon: AppIconId
    }>
    /** Фон новой вкладки: дочерние webview не видят BroadcastChannel главного. */
    notifyWallpaper(action: 'update' | 'clear'): Promise<void>
  }
  window: {
    minimize(): void
    toggleMaximize(): void
    close(): void
    toggleFullscreen(): void
  }
  setChromeHeight(height: number): void
  onState(cb: (state: AppState) => void): () => void
  onFocusOmnibox(cb: () => void): () => void
  onCloseOverlay(cb: () => void): () => void
  onCloseDownloads(cb: () => void): () => void
  onToast(cb: (text: string) => void): () => void
  onDownloadsUpdated(cb: (items: DownloadItem[]) => void): () => void
  onSettings(cb: (settings: SettingsSync) => void): () => void
  onUiTheme(cb: (preset: UiPreset) => void): () => void
}
