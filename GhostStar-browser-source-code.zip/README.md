# GhostStar Browser

Минимальная рабочая версия браузера на **Rust + Tauri + WebView2** с интерфейсом Material 3 Expressive.

Проект переименован, чтобы не конфликтовать с существующим продуктом с похожим названием.

## Что есть

- вкладки, адресная строка и навигация;
- панель загрузок;
- настройки: светлая/тёмная тема и акцентный цвет.

Лишние модули (редактор интерфейса, обои, ИИ-чат, звуки, пасхалки) вырезаны.

## Запуск

```bash
npm install
npm run typecheck
npm run build
cargo check --manifest-path src-tauri/Cargo.toml
npm run tauri:dev
```

Vite поднимается на `127.0.0.1:1434`, HMR — на `1435`, чтобы не конфликтовать с другими проектами.

## Стек

- Tauri 2 / Rust;
- WebView2 на Windows;
- Vite + TypeScript;
- `@materialwebunofficial/md3e-web` для токенов и компонентов Material 3.
