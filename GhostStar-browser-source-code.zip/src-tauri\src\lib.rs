//! GhostStar Browser — бэкенд на Tauri. Вкладки живут в одном окне как дочерние WebView2.

mod commands;
mod downloads;
mod state;
mod tabs;

use std::sync::{atomic::{AtomicBool, Ordering}, Mutex};

use tauri::{Manager, WindowEvent};

use crate::state::BrowserState;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .manage(Mutex::new(BrowserState::default()))
        .invoke_handler(tauri::generate_handler![
            commands::state,
            commands::create_tab,
            commands::close_tab,
            commands::select_tab,
            commands::reopen_tab,
            commands::navigate,
            commands::nav,
            commands::set_zoom,
            commands::toggle_devtools,
            commands::webview_shortcut,
            commands::set_overlay,
            commands::set_downloads,
            commands::set_ui_editor,
            commands::apply_settings,
            commands::get_ui_theme,
            commands::set_ui_theme,
            commands::reset_ui_theme,
            commands::get_settings,
            commands::set_chrome_height,
            commands::notify_wallpaper,
            commands::get_downloads,
            commands::clear_downloads,
            commands::remove_download,
            commands::open_download,
            commands::show_download_in_folder,
            commands::pause_download,
            commands::resume_download,
            commands::cancel_download,
            commands::choose_download_dir,
            commands::open_downloads_folder,
            commands::get_custom_app_icon,
            commands::save_custom_app_icon,
            commands::capture_page,
        ])
        .setup(|app| {
            let app_handle = app.handle().clone();

            // Настройки переживают перезапуск: читаем settings.json до первой вкладки.
            {
                let loaded = state::load_settings(&app_handle);
                commands::apply_app_icon(&app_handle, &loaded.app_icon);
                let st = app_handle.state::<Mutex<BrowserState>>();
                st.lock().unwrap().settings = loaded;
            }

            let window = app
                .get_webview_window("main")
                .ok_or_else(|| "главное окно не найдено".to_string())?;

            // Ресайз/максимизация: перекладываем webview и обновляем состояние.
            let last_max = ArcAtomicBool::new(false);
            window.on_window_event({
                let h = app_handle.clone();
                let last = last_max.clone();
                move |event| match event {
                    WindowEvent::Resized(_) | WindowEvent::ScaleFactorChanged { .. } => {
                        let layout_h = h.clone();
                        let state_h = h.clone();
                        tauri::async_runtime::spawn(async move {
                            tabs::layout_webviews(&layout_h);
                        });
                        let now = h
                            .get_webview_window("main")
                            .and_then(|w| w.is_maximized().ok())
                            .unwrap_or(false);
                        if last.swap(now, Ordering::Relaxed) != now {
                            tabs::emit_state(&state_h);
                        }
                    }
                    WindowEvent::Focused(_) => {
                        let focus_h = h.clone();
                        tauri::async_runtime::spawn(async move {
                            tabs::emit_state(&focus_h);
                        });
                    }
                    _ => {}
                }
            });

            // Первую вкладку создаём асинхронно: add_child блокирует главный поток.
            let h = app_handle.clone();
            tauri::async_runtime::spawn(async move {
                if let Err(e) = tabs::create_tab(&h, None, false) {
                    tabs::emit_toast(&h, format!("Не удалось открыть вкладку: {e}"));
                }
                tabs::emit_state(&h);
            });

            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("не удалось запустить GhostStar Browser");
}

/// Маленькая обёртка, чтобы не импортировать Arc отдельно.
#[derive(Clone)]
struct ArcAtomicBool {
    inner: std::sync::Arc<AtomicBool>,
}

impl ArcAtomicBool {
    fn new(value: bool) -> Self {
        Self {
            inner: std::sync::Arc::new(AtomicBool::new(value)),
        }
    }

    fn swap(&self, value: bool, order: Ordering) -> bool {
        self.inner.swap(value, order)
    }
}
