//! Управление настоящими вкладками: каждая вкладка — дочерний WebView2 в одном окне.

use std::sync::Mutex;

use tauri::{
    webview::{DownloadEvent, PageLoadEvent, WebviewBuilder},
    AppHandle, Emitter, LogicalPosition, LogicalSize, Manager, PhysicalSize, Url, Webview,
    WebviewUrl,
};

use crate::state::{
    accent_with_saturation, system_accent, window_info_from_app, BrowserState, TabInfo, TabRuntime,
};

/// Базовый адрес локального фронтенда (для «домой»).
fn app_base_url() -> &'static str {
    if cfg!(debug_assertions) {
        "http://127.0.0.1:1432/"
    } else {
        "http://tauri.localhost/"
    }
}

fn percent_encode(input: &str) -> String {
    let mut out = String::with_capacity(input.len());
    for &b in input.as_bytes() {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => {
                out.push(b as char)
            }
            _ => out.push_str(&format!("%{b:02X}")),
        }
    }
    out
}

/// Превращает ввод в адресной строке в URL.
pub fn normalize_input(raw: &str, engine: &str) -> String {
    let text = raw.trim();
    if text.is_empty() {
        return app_base_url().to_string();
    }
    if text.starts_with("http://") || text.starts_with("https://") || text.starts_with("file://") {
        return text.to_string();
    }
    // localhost / IP / похоже на домен
    let looks_like_host = text.starts_with("localhost")
        || text.split('.').count() >= 2 && !text.contains(' ');
    if looks_like_host {
        return format!("https://{text}");
    }
    let q = percent_encode(text);
    match engine {
        "google" => format!("https://www.google.com/search?q={q}"),
        "duckduckgo" => format!("https://duckduckgo.com/?q={q}"),
        "bing" => format!("https://www.bing.com/search?q={q}"),
        _ => format!("https://yandex.ru/search/?text={q}"),
    }
}

/// URL страницы «Новая вкладка» с параметрами из настроек.
fn newtab_url(app: &AppHandle) -> String {
    let (scheme, accent, engine, ui, language, saturation) = {
        let st = app.state::<Mutex<BrowserState>>();
        let s = st.lock().unwrap();
        (
            s.settings.scheme.clone(),
            s.settings.accent.clone().unwrap_or_else(system_accent),
            s.settings.search_engine.clone(),
            serde_json::to_string(&s.settings.ui_theme).unwrap_or_else(|_| "{}".into()),
            s.settings.language.clone(),
            serde_json::to_string(&s.settings.saturation).unwrap_or_else(|_| "null".into()),
        )
    };
    // `auto` передаём как есть — newtab.ts сам сверит его с системной темой.
    // Пресет UI передаём в URL: событие `ghost://ui-theme` к новой вкладке
    // придёт только после её создания, а первое состояние нужно сразу.
    format!(
        "newtab.html?scheme={}&accent={}&engine={engine}&ui={}&lang={language}&saturation={saturation}&noautofocus=1",
        percent_encode(&scheme),
        percent_encode(&accent),
        percent_encode(&ui)
    )
}

pub fn emit_state(app: &AppHandle) {
    let mut public = {
        let st = app.state::<Mutex<BrowserState>>();
        let s = st.lock().unwrap();
        s.public_state()
    };
    public.window = window_info_from_app(app);
    let _ = app.emit("ghost://state", public);
}

pub fn emit_toast(app: &AppHandle, text: impl Into<String>) {
    let _ = app.emit("ghost://toast", text.into());
}

/// Фиксирует навигацию, которую сделала сама страница (ссылка, location.href).
/// `navigate()`/`nav()` уже кладут целевой URL в историю — здесь проверка по
/// последнему элементу не даёт дубликатов и не ломает «назад/вперёд».
/// `https://site.ru` и `https://site.ru/` — один и тот же адрес. WebView2
/// часто догоняет наш URL именно так; без этой проверки «назад/вперёд»
/// получал дубли и застревал на одном сайте.
fn urls_equivalent(a: &str, b: &str) -> bool {
    let base = |s: &str| s.split('#').next().unwrap_or(s).trim_end_matches('/').to_string();
    base(a) == base(b)
}

fn sync_history(s: &mut BrowserState, tab_id: u32, url: &str) {
    if url.starts_with("about:") || url.starts_with("devtools:") {
        return;
    }
    let Some(tab) = s.find_mut(tab_id) else {
        return;
    };
    if tab.history.get(tab.history_index).map(|u| u.as_str()) != Some(url) {
        // Нормализованный адрес заменяем в текущей записи, а не добавляем
        // новую — иначе кнопка «назад» вела туда же, где мы уже были.
        if tab
            .history
            .get(tab.history_index)
            .is_some_and(|u| urls_equivalent(u, url))
        {
            tab.history[tab.history_index] = url.to_string();
        } else {
            if tab.history_index + 1 < tab.history.len() {
                tab.history.truncate(tab.history_index + 1);
            }
            tab.history.push(url.to_string());
            tab.history_index = tab.history.len() - 1;
        }
    }
    tab.info.can_go_back = tab.history_index > 0;
    tab.info.can_go_forward = tab.history_index + 1 < tab.history.len();
    let is_new_tab = url.contains("newtab.html");
    tab.info.is_new_tab = is_new_tab;
    tab.info.url = if is_new_tab { String::new() } else { url.to_string() };
    tab.info.display_url = tab.info.url.clone();
}

/// Перекладывает дочерние webview под хром. Модальное окно рисуется в основном
/// webview, поэтому на время его показа вкладки скрываются: иначе WebView2
/// перекрыл бы диалог и затемнение.
pub fn layout_webviews(app: &AppHandle) {
    let (chrome_height, active_id, modal_open, ids): (
        f64,
        Option<u32>,
        bool,
        Vec<(u32, String)>,
    ) = {
        let st = app.state::<Mutex<BrowserState>>();
        let s = st.lock().unwrap();
        (
            s.chrome_height,
            s.active_id,
            s.settings_open || s.downloads_open || s.ui_editor_open,
            s.tabs.iter().map(|t| (t.info.id, t.label.clone())).collect(),
        )
    };
    let win = match app.get_window("main") {
        Some(w) => w,
        None => return,
    };
    let scale = win.scale_factor().unwrap_or(1.0);
    let size: LogicalSize<f64> = win
        .inner_size()
        .unwrap_or(PhysicalSize::new(1280, 800))
        .to_logical(scale);
    let body_h = (size.height - chrome_height).max(80.0);
    let page_w = size.width.max(240.0);

    for (id, label) in ids {
        if let Some(wv) = app.get_webview(&label) {
            if modal_open {
                let _ = wv.hide();
                continue;
            }
            let _ = wv.set_position(LogicalPosition::new(0.0, chrome_height));
            let _ = wv.set_size(LogicalSize::new(page_w, body_h));
            if active_id == Some(id) {
                let _ = wv.show();
            } else {
                let _ = wv.hide();
            }
        }
    }
}

/// Хоткеи, которые ловит сама страница вкладки. Слушатель `keydown` в
/// основном webview не получает клавиши из дочернего WebView2 — поэтому
/// перехватываем их здесь и пересылаем одной Tauri-командой.
const PAGE_SHORTCUTS_JS: &str = r#"
(() => {
  if (window.__ghostShortcuts) return;
  window.__ghostShortcuts = 1;
  const call = (action, arg) => {
    const i = window.__TAURI_INTERNALS__;
    if (!i || typeof i.invoke !== 'function') return;
    i.invoke('webview_shortcut', { action, arg: arg ?? null }).catch(() => {});
  };
  document.addEventListener('keydown', (event) => {
    if (event.defaultPrevented || event.isComposing) return;
    const k = event.key.toLowerCase();
    const c = event.ctrlKey || event.metaKey;
    let action = '';
    let arg = null;
    if (k === 'f5') { action = 'nav'; arg = event.shiftKey ? 'hard-reload' : 'reload'; }
    else if (k === 'f11') action = 'fullscreen';
    else if (k === 'f12' || (c && event.shiftKey && k === 'i')) action = 'devtools';
    else if (c && event.shiftKey && k === 't') action = 'reopen-tab';
    else if (c && !event.shiftKey && k === 't') action = 'new-tab';
    else if (c && k === 'w') action = 'close-tab';
    else if (c && k === 'l') action = 'focus-omnibox';
    else if (c && k === 'tab') { action = 'cycle-tab'; arg = event.shiftKey ? '-1' : '1'; }
    else if (c && k === 'r') { action = 'nav'; arg = event.shiftKey ? 'hard-reload' : 'reload'; }
    else if (c && (k === '=' || k === '+')) { action = 'zoom'; arg = '0.1'; }
    else if (c && k === '-') { action = 'zoom'; arg = '-0.1'; }
    else if (c && k === '0') { action = 'zoom'; arg = 'reset'; }
    else if (event.altKey && !c && k === 'arrowleft') { action = 'nav'; arg = 'back'; }
    else if (event.altKey && !c && k === 'arrowright') { action = 'nav'; arg = 'forward'; }
    else if (event.altKey && !c && k === 'd') action = 'focus-omnibox';
    else if (c && /^[1-9]$/.test(k)) { action = 'select-tab-index'; arg = k; }
    if (!action) return;
    event.preventDefault();
    event.stopPropagation();
    call(action, arg);
  }, true);
})();
"#;

/// Те же 5 пресетов курсора, что в `cursor.ts`, но для сайтов внутри вкладок.
/// Их DOM нам не принадлежит, поэтому ставим стиль через initialization script
/// и функцию `__ghostSetCursor(preset, accent)`, которую дёргаем при смене
/// пресета или акцента. Плейсхолдеры заменяются на безопасные строки при создании webview.
const CURSOR_JS: &str = r##"
(() => {
  if (window.__ghostSetCursor) return;
  const D = 'M4 2.6c-.8 0-1.4.6-1.4 1.4v20.3c0 1.1 1.3 1.7 2.1.9l4.4-4.4 4.3 8.4c.3.6 1.1.9 1.7.6l3.2-1.6c.7-.3 1-1.1.6-1.7l-4.1-8 8.7-.3c1.1 0 1.6-1.4.7-2.1L5.4 2.9c-.4-.4-.9-.3-1.4-.3Z';
  const SHAPES = {
    ghost: (a) => ({ size: 30, hotspot: '3 2', body:
      '<path d="' + D + '" fill="' + a + '" stroke="#fff" stroke-width="2" stroke-linejoin="round"/>' +
      '<circle cx="9" cy="9" r="1.5" fill="#fff" opacity="0.9"/>' }),
    classic: (a) => ({ size: 30, hotspot: '3 2', body:
      '<path d="' + D + '" fill="#fff" stroke="#1f1b25" stroke-width="2" stroke-linejoin="round"/>' +
      '<circle cx="9" cy="9" r="1.5" fill="#1f1b25" opacity="0.85"/>' }),
    neon: (a) => ({ size: 34, hotspot: '4 2', body:
      '<path d="' + D + '" fill="' + a + '" opacity="0.22" stroke="' + a + '" stroke-width="6" stroke-linejoin="round"/>' +
      '<path d="' + D + '" fill="' + a + '" stroke="#fff" stroke-width="1.6" stroke-linejoin="round"/>' +
      '<circle cx="9" cy="9" r="1.6" fill="#fff"/>' }),
    outline: (a) => ({ size: 30, hotspot: '3 2', body:
      '<path d="' + D + '" fill="none" stroke="#fff" stroke-width="4.6" stroke-linejoin="round" opacity="0.9"/>' +
      '<path d="' + D + '" fill="none" stroke="' + a + '" stroke-width="2.2" stroke-linejoin="round"/>' +
      '<circle cx="9" cy="9" r="1.3" fill="' + a + '"/>' }),
    minimal: (a) => ({ size: 24, hotspot: '2 1', body:
      '<path d="' + D + '" fill="' + a + '"/>' })
  };
  const set = (preset, accent) => {
    const names = ['ghost', 'classic', 'neon', 'outline', 'minimal'];
    const p = names.indexOf(preset) >= 0 ? preset : 'ghost';
    const hex = /^#[0-9a-f]{6}$/i.test(accent) ? accent : '#6750a4';
    const s = (SHAPES[p] || SHAPES.ghost)(hex);
    const svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' + s.size + '" height="' + s.size + '" viewBox="-2 -2 34 34">' + s.body + '</svg>';
    const value = 'url("data:image/svg+xml,' + encodeURIComponent(svg) + '") ' + s.hotspot + ', auto';
    let style = document.getElementById('ghost-accent-cursor');
    if (!style) {
      style = document.createElement('style');
      style.id = 'ghost-accent-cursor';
      document.head.appendChild(style);
    }
    style.textContent = "html,body,a,button,summary,label,[role='button']{cursor:" + value + "!important}";
  };
  window.__ghostSetCursor = set;
  const initial = [__GHOST_PRESET__, __GHOST_ACCENT__];
  if (document.head) set(initial[0], initial[1]);
  else document.addEventListener('DOMContentLoaded', () => set(initial[0], initial[1]), { once: true });
})();
"##;

/// Hex из настроек/Windows: в JS уйдёт только безопасное значение.
fn cursor_hex(accent: &str) -> String {
    let raw: String = accent
        .trim()
        .trim_start_matches('#')
        .chars()
        .filter(|c| c.is_ascii_hexdigit())
        .take(6)
        .collect();
    if raw.len() == 6 {
        format!("#{raw}")
    } else {
        "#6750a4".to_string()
    }
}

/// Живая смена курсора в сайтах-вкладках. Главный webview и новая вкладка
/// обновляются сами — через `applyTheme()` в TS.
pub fn apply_cursor(app: &AppHandle, accent: &str, preset: &str) {
    let preset = crate::state::normalize_cursor_preset(preset);
    let script = format!(
        "if(window.__ghostSetCursor)window.__ghostSetCursor('{}','{}');",
        preset,
        cursor_hex(accent)
    );
    let labels: Vec<String> = {
        let st = app.state::<Mutex<BrowserState>>();
        let Ok(s) = st.lock() else {
            return;
        };
        s.tabs.iter().map(|t| t.label.clone()).collect()
    };
    // Лок уже отпущен: eval по нескольким webview может занять время.
    for label in labels {
        if let Some(wv) = app.get_webview(&label) {
            let _ = wv.eval(&script);
        }
    }
}

/// Масштаб хранится в состоянии браузера, а применяется к DOM страницы.
/// При переходе/обновлении DOM создаётся заново — навешиваем zoom заново.
fn reapply_zoom(app: &AppHandle, webview: &Webview) {
    let zoom = {
        let st = app.state::<Mutex<BrowserState>>();
        st.lock().map(|s| s.zoom).unwrap_or(1.0)
    };
    let _ = webview.eval(format!("if(document.body)document.body.style.zoom='{zoom}';"));
}

fn build_webview(app: &AppHandle, id: u32, label: &str, target: WebviewUrl) -> Result<Webview, String> {
    let (accent, saturation, cursor_preset) = {
        let st = app.state::<Mutex<BrowserState>>();
        st.lock()
            .map(|s| {
                (
                    s.settings
                        .accent
                        .clone()
                        .unwrap_or_else(crate::state::system_accent),
                    s.settings.saturation,
                    s.settings.cursor_preset.clone(),
                )
            })
            .unwrap_or_else(|_| ("#6750a4".to_string(), None, "ghost".to_string()))
    };
    let cursor_color = cursor_hex(&accent_with_saturation(&accent, saturation));
    let cursor_preset = crate::state::normalize_cursor_preset(&cursor_preset);
    let cursor_js = CURSOR_JS
        .replace("__GHOST_PRESET__", &format!("'{cursor_preset}'"))
        .replace("__GHOST_ACCENT__", &format!("'{cursor_color}'"));
    let builder = WebviewBuilder::new(label, target)
        .initialization_script(PAGE_SHORTCUTS_JS)
        .initialization_script(cursor_js.as_str())
        .on_navigation({
            let app_handle = app.clone();
            let tab_id = id;
            move |_url| {
                if let Some(st) = app_handle.try_state::<Mutex<BrowserState>>() {
                    if let Ok(mut s) = st.lock() {
                        if let Some(tab) = s.find_mut(tab_id) {
                            tab.info.loading = true;
                        }
                        // Историю пишем только на Finished: on_navigation и
                        // Started приходят для каждого редиректа и дублируют
                        // записи, из-за чего ломался back/forward.
                    }
                }
                true
            }
        })
        .on_page_load({
            let app_handle = app.clone();
            let tab_id = id;
            move |_webview, payload| {
                let url = payload.url().to_string();
                match payload.event() {
                    PageLoadEvent::Started => {
                        if let Some(st) = app_handle.try_state::<Mutex<BrowserState>>() {
                            if let Ok(mut s) = st.lock() {
                                if let Some(tab) = s.find_mut(tab_id) {
                                    tab.info.loading = true;
                                }
                            }
                        }
                    }
                    PageLoadEvent::Finished => {
                        if let Some(st) = app_handle.try_state::<Mutex<BrowserState>>() {
                            if let Ok(mut s) = st.lock() {
                                if let Some(tab) = s.find_mut(tab_id) {
                                    tab.info.loading = false;
                                    tab.info.error = None;
                                }
                                sync_history(&mut s, tab_id, &url);
                            }
                        }
                        // Результаты поиска часто открываются через target="_blank" или
                        // window.open(). В MVP нет поддержки новых окон — перенаправляем
                        // в ту же вкладку и возвращаем заглушку вместо реального window.
                        let same_tab = r#"
(() => {
  try {
    for (const a of document.querySelectorAll('a[target="_blank"],a[target="new"]')) {
      a.setAttribute('target', '_self');
    }
    document.addEventListener('click', (e) => {
      const a = e.target && e.target.closest ? e.target.closest('a[target]') : null;
      if (a && /^(blank|new)$/i.test(a.getAttribute('target') || '')) {
        a.setAttribute('target', '_self');
      }
    }, true);
    if (!window.open.__ghostShim) {
      const shim = (target) => {
        if (target) location.href = String(target);
        return { closed: false, document: {}, focus() {}, close() {}, blur() {} };
      };
      shim.__ghostShim = true;
      window.open = shim;
    }
  } catch (_) {}
})()
"#;
                        let _ = _webview.eval(same_tab);
                        reapply_zoom(&app_handle, &_webview);
                    }
                }
                emit_state(&app_handle);
            }
        })
        .on_document_title_changed({
            let app_handle = app.clone();
            let tab_id = id;
            move |_webview, title| {
                if title.is_empty() {
                    return;
                }
                if let Some(st) = app_handle.try_state::<Mutex<BrowserState>>() {
                    if let Ok(mut s) = st.lock() {
                        if let Some(tab) = s.find_mut(tab_id) {
                            tab.info.title = title;
                        }
                    }
                }
                emit_state(&app_handle);
            }
        })
        .on_download({
            let app_handle = app.clone();
            move |_webview, event| {
                match event {
                    DownloadEvent::Requested { url, destination } => {
                        crate::downloads::requested(&app_handle, &url, destination);
                    }
                    DownloadEvent::Finished { url, path, success } => {
                        crate::downloads::finished(&app_handle, &url, path.as_ref(), success);
                    }
                    _ => {}
                }
                // Пропускаем загрузку — WebView2 сохраняет файл сам.
                true
            }
        });

    let win = app
        .get_window("main")
        .ok_or_else(|| "главное окно не найдено".to_string())?;
    let scale = win.scale_factor().unwrap_or(1.0);
    let size: LogicalSize<f64> = win
        .inner_size()
        .unwrap_or(PhysicalSize::new(1280, 800))
        .to_logical(scale);
    let chrome_height = {
        let st = app.state::<Mutex<BrowserState>>();
        let s = st.lock().unwrap();
        s.chrome_height
    };
    let body_h = (size.height - chrome_height).max(80.0);

    win.add_child(
        builder,
        LogicalPosition::new(0.0, chrome_height),
        LogicalSize::new(size.width, body_h),
    )
    .map_err(|e| format!("не удалось создать webview вкладки: {e}"))
}

pub fn create_tab(app: &AppHandle, url: Option<String>, background: bool) -> Result<u32, String> {
    let provided = url.filter(|u| !u.trim().is_empty());
    let is_newtab = provided.is_none();
    // newtab_url() сама берёт блокировку состояния — считаем её ДО захвата локов,
    // иначе std::sync::Mutex заблокирует сам себя и окно зависнет.
    let home_target = if is_newtab {
        Some(newtab_url(app))
    } else {
        None
    };
    let engine = {
        let st = app.state::<Mutex<BrowserState>>();
        let engine = st.lock().unwrap().settings.search_engine.clone();
        engine
    };
    let target = match (&provided, home_target) {
        (Some(u), _) => normalize_input(u, &engine),
        (None, Some(h)) => h,
        (None, None) => unreachable!(),
    };

    // Парсим адрес ДО вставки вкладки в состояние. Иначе при битом URL в списке
    // останется «фантом»: вкладка есть, а webview для неё никогда не создан.
    let webview_url = if is_newtab {
        WebviewUrl::App(target.clone().into())
    } else {
        WebviewUrl::External(Url::parse(&target).map_err(|e| format!("неверный адрес: {e}"))?)
    };

    let (id, label) = {
        let st = app.state::<Mutex<BrowserState>>();
        let mut s = st.lock().unwrap();
        let id = s.next_id;
        s.next_id += 1;
        let label = format!("tab_{id}");

        let title = if is_newtab {
            "Новая вкладка".to_string()
        } else {
            target.clone()
        };
        let info = TabInfo {
            id,
            title,
            url: if is_newtab { String::new() } else { target.clone() },
            display_url: if is_newtab { String::new() } else { target.clone() },
            favicon: None,
            loading: !is_newtab,
            can_go_back: false,
            can_go_forward: false,
            is_new_tab: is_newtab,
            audible: false,
            error: None,
        };
        // Новая вкладка — тоже страница в истории: иначе после первого перехода
        // кнопка «назад» была бы неактивной и вернуться было бы нельзя.
        let first_url = if is_newtab {
            format!("{}{}", app_base_url(), target)
        } else {
            target.clone()
        };
        s.tabs.push(TabRuntime {
            info,
            label: label.clone(),
            history: vec![first_url],
            history_index: 0,
        });
        (id, label)
    };

    // add_child на Windows блокирует главный поток — вызываем только из async-команды.
    let webview = match build_webview(app, id, &label, webview_url) {
        Ok(w) => w,
        Err(e) => {
            // Откатываем запись: без webview вкладка не имеет смысла.
            let st = app.state::<Mutex<BrowserState>>();
            if let Ok(mut s) = st.lock() {
                s.tabs.retain(|t| t.info.id != id);
                if s.active_id == Some(id) {
                    s.active_id = s.tabs.last().map(|t| t.info.id);
                }
            }
            emit_state(app);
            return Err(e);
        }
    };
    if background {
        let _ = webview.hide();
    } else {
        let previous = {
            let st = app.state::<Mutex<BrowserState>>();
            let mut s = st.lock().unwrap();
            let previous = s.active_id;
            s.active_id = Some(id);
            previous
        };
        if let Some(prev) = previous {
            let prev_label = {
                let st = app.state::<Mutex<BrowserState>>();
                let s = st.lock().unwrap();
                s.find(prev).map(|t| t.label.clone())
            };
            if let Some(l) = prev_label {
                if let Some(w) = app.get_webview(&l) {
                    let _ = w.hide();
                }
            }
        }
        let _ = webview.show();
        let _ = webview.set_focus();
    }

    emit_state(app);
    // Соблюдаем состояние модалок: во время загрузки/старта вкладка создана,
    // но её webview должна оставаться скрытой, пока диалог/оверлей не закроется.
    layout_webviews(app);
    Ok(id)
}

pub fn close_tab(app: &AppHandle, id: u32) -> Result<(), String> {
    // Запоминаем вкладку для Ctrl+Shift+T и сразу решаем, что показывать дальше.
    let (label, next_active, tabs_left) = {
        let st = app.state::<Mutex<BrowserState>>();
        let mut s = st.lock().unwrap();
        let Some(index) = s.tabs.iter().position(|t| t.info.id == id) else {
            return Ok(());
        };
        let label = s.tabs[index].label.clone();
        let was_active = s.active_id == Some(id);

        // Пустой URL = «Новая вкладка» — create_tab() поймёт его корректно.
        let closed = (s.tabs[index].info.url.clone(), s.tabs[index].info.title.clone());
        s.closed_tabs.push(closed);
        s.closed_tabs.truncate(30);

        s.tabs.remove(index);
        if was_active {
            s.active_id = s
                .tabs
                .get(index.min(s.tabs.len().saturating_sub(1)))
                .map(|t| t.info.id);
        }
        let next = if was_active { s.active_id } else { None };
        (label, next, s.tabs.is_empty())
    };

    if let Some(wv) = app.get_webview(&label) {
        let _ = wv.close();
    }

    if let Some(next) = next_active {
        let next_label = {
            let st = app.state::<Mutex<BrowserState>>();
            let s = st.lock().unwrap();
            s.find(next).map(|t| t.label.clone())
        };
        if let Some(l) = next_label {
            if let Some(w) = app.get_webview(&l) {
                let _ = w.show();
                let _ = w.set_focus();
            }
        }
    }

    // Браузер не должен оставаться без единой вкладки — браузер с пустым
    // окном выглядит сломанным, особенно после Ctrl+W на последней вкладке.
    if tabs_left {
        create_tab(app, None, false)?;
    } else {
        emit_state(app);
    }
    Ok(())
}

pub fn select_tab(app: &AppHandle, id: u32) -> Result<(), String> {
    let (active_label, other_labels) = {
        let st = app.state::<Mutex<BrowserState>>();
        let mut s = st.lock().unwrap();
        if s.find(id).is_none() {
            return Ok(());
        }
        s.active_id = Some(id);
        let active = s.find(id).unwrap().label.clone();
        let others: Vec<String> = s
            .tabs
            .iter()
            .filter(|t| t.info.id != id)
            .map(|t| t.label.clone())
            .collect();
        (active, others)
    };
    for label in other_labels {
        if let Some(w) = app.get_webview(&label) {
            let _ = w.hide();
        }
    }
    if let Some(w) = app.get_webview(&active_label) {
        let _ = w.show();
        let _ = w.set_focus();
    }
    emit_state(app);
    Ok(())
}

pub fn navigate(app: &AppHandle, id: u32, raw: &str) -> Result<(), String> {
    let raw = raw.trim();
    let go_home = raw.is_empty() || raw == "home";
    // newtab_url() сама блокирует состояние — считаем до захвата локов.
    let home_target = if go_home {
        format!("{}{}", app_base_url(), newtab_url(app))
    } else {
        String::new()
    };
    let (label, target) = {
        let st = app.state::<Mutex<BrowserState>>();
        let mut s = st.lock().unwrap();
        let engine = s.settings.search_engine.clone();
        let tab = s.find_mut(id).ok_or_else(|| "вкладка не найдена".to_string())?;
        let target = if go_home {
            home_target
        } else {
            normalize_input(raw, &engine)
        };
        tab.info.loading = true;
        tab.info.is_new_tab = target.contains("newtab.html");
        let label = tab.label.clone();
        // история
        if tab.history_index + 1 < tab.history.len() {
            tab.history.truncate(tab.history_index + 1);
        }
        tab.history.push(target.clone());
        tab.history_index = tab.history.len() - 1;
        tab.info.can_go_back = tab.history_index > 0;
        tab.info.can_go_forward = false;
        tab.info.url = if tab.info.is_new_tab { String::new() } else { target.clone() };
        tab.info.display_url = if tab.info.is_new_tab { String::new() } else { target.clone() };
        (label, target)
    };
    let wv = app.get_webview(&label).ok_or_else(|| "webview вкладки не найден".to_string())?;
    wv.navigate(Url::parse(&target).map_err(|e| format!("неверный адрес: {e}"))?)
        .map_err(|e| format!("не удалось перейти: {e}"))?;
    emit_state(app);
    Ok(())
}

pub fn nav(app: &AppHandle, action: &str) -> Result<(), String> {
    let id = {
        let st = app.state::<Mutex<BrowserState>>();
        let s = st.lock().unwrap();
        s.active_id.ok_or_else(|| "нет активной вкладки".to_string())?
    };
    match action {
        "back" | "forward" => {
            let (label, target) = {
                let st = app.state::<Mutex<BrowserState>>();
                let mut s = st.lock().unwrap();
                let tab = s.find_mut(id).ok_or_else(|| "вкладка не найдена".to_string())?;
                let next_index = if action == "back" {
                    tab.history_index.saturating_sub(1)
                } else {
                    (tab.history_index + 1).min(tab.history.len().saturating_sub(1))
                };
                if next_index == tab.history_index {
                    return Ok(());
                }
                tab.history_index = next_index;
                tab.info.can_go_back = next_index > 0;
                tab.info.can_go_forward = next_index + 1 < tab.history.len();
                let target = tab.history[next_index].clone();
                tab.info.url = target.clone();
                tab.info.display_url = target.clone();
                tab.info.is_new_tab = target.contains("newtab.html");
                (tab.label.clone(), target)
            };
            let wv = app.get_webview(&label).ok_or_else(|| "webview вкладки не найден".to_string())?;
            wv.navigate(Url::parse(&target).map_err(|e| format!("неверный адрес: {e}"))?)
        .map_err(|e| format!("не удалось перейти: {e}"))?;
        }
        "reload" | "hard-reload" | "stop" => {
            let label = {
                let st = app.state::<Mutex<BrowserState>>();
                let s = st.lock().unwrap();
                s.find(id).map(|t| t.label.clone())
            };
            let Some(label) = label else { return Ok(()) };
            let wv = app.get_webview(&label).ok_or_else(|| "webview вкладки не найден".to_string())?;
            if action == "stop" {
                let _ = wv.eval("window.stop()");
            } else {
                wv.reload().map_err(|e| format!("не удалось обновить: {e}"))?;
            }
        }
        "home" => {
            let base = app_base_url();
            let target = format!("{base}{}", newtab_url(app));
            let label = {
                let st = app.state::<Mutex<BrowserState>>();
                let mut s = st.lock().unwrap();
                let tab = s.find_mut(id).ok_or_else(|| "вкладка не найдена".to_string())?;
                tab.info.is_new_tab = true;
                tab.info.url.clear();
                tab.info.display_url.clear();
                tab.label.clone()
            };
            let wv = app.get_webview(&label).ok_or_else(|| "webview вкладки не найден".to_string())?;
            wv.navigate(Url::parse(&target).map_err(|e| format!("неверный адрес: {e}"))?)
        .map_err(|e| format!("не удалось перейти: {e}"))?;
        }
        _ => return Err(format!("неизвестное действие: {action}")),
    }
    emit_state(app);
    Ok(())
}

pub fn set_chrome_height(app: &AppHandle, height: f64) {
    {
        let st = app.state::<Mutex<BrowserState>>();
        let mut s = st.lock().unwrap();
        let h = height.max(0.0).min(400.0);
        if (s.chrome_height - h).abs() < 0.5 {
            return;
        }
        s.chrome_height = h;
    }
    layout_webviews(app);
}

pub fn set_zoom(app: &AppHandle, delta: &str) -> Result<(), String> {
    let (label, next_zoom) = {
        let st = app.state::<Mutex<BrowserState>>();
        let mut s = st.lock().unwrap();
        let id = s.active_id.ok_or_else(|| "нет активной вкладки".to_string())?;
        let label = s.find(id).ok_or_else(|| "вкладка не найдена".to_string())?.label.clone();
        let next = if delta == "reset" {
            1.0
        } else {
            let d: f64 = delta.parse().unwrap_or(0.0);
            (s.zoom + d).clamp(0.5, 2.0)
        };
        s.zoom = next;
        (label, next)
    };
    if let Some(wv) = app.get_webview(&label) {
        let script = format!("document.body.style.zoom = '{next_zoom}'");
        let _ = wv.eval(script);
    }
    emit_toast(app, format!("Масштаб: {}%", (next_zoom * 100.0).round() as i32));
    Ok(())
}

pub fn reopen_tab(app: &AppHandle) -> Result<(), String> {
    let (url, title) = {
        let st = app.state::<Mutex<BrowserState>>();
        let mut s = st.lock().unwrap();
        s.closed_tabs
            .pop()
            .ok_or_else(|| "Нет закрытых вкладок".to_string())?
    };

    let id = create_tab(app, Some(url), false)?;
    if !title.is_empty() {
        let st = app.state::<Mutex<BrowserState>>();
        let mut s = st.lock().unwrap();
        if let Some(tab) = s.find_mut(id) {
            tab.info.title = title;
        }
    }
    emit_state(app);
    emit_toast(app, "Вкладка восстановлена");
    Ok(())
}
