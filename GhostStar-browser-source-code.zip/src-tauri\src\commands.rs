//! Tauri-команды, которые вызывает фронтенд через `window.ghost.invoke.*`.

use std::{
    path::Path,
    sync::{
        atomic::{AtomicBool, Ordering},
        Mutex,
    },
};

use tauri::{AppHandle, Emitter, Manager, State};
use base64::{engine::general_purpose, Engine as _};

use crate::{
    state::{
        accent_with_saturation, custom_app_icon_path, load_settings, normalize_app_icon,
        normalize_cursor_preset, normalize_dialog_style, normalize_language, normalize_saturation,
        save_settings, system_accent, window_info_from_app, AppState,
        BrowserState, DownloadItem, Settings, SettingsPatch, UiTheme,
    },
    tabs,
};

type Browser<'a> = State<'a, Mutex<BrowserState>>;

/// wry на WebView2 не умеет закрывать DevTools, поэтому не открываем окно дважды.
static DEVTOOLS_OPENED: AtomicBool = AtomicBool::new(false);

/// Живые настройки для домашней вкладки. Акцент уже решён: для «цвета системы»
/// newtab должен получить реальный цвет Windows, а не фиктивный `#6a4bd8`.
fn emit_settings(app: &AppHandle, settings: &Settings) {
    let accent = settings.accent.clone().unwrap_or_else(system_accent);
    let _ = app.emit(
        "ghost://settings",
        serde_json::json!({
            "scheme": settings.scheme,
            "accent": accent,
            "searchEngine": settings.search_engine,
            "language": settings.language,
            "saturation": settings.saturation,
            "cursorPreset": settings.cursor_preset,
            "sounds": settings.sounds,
            "appIcon": settings.app_icon,
        }),
    );
}

/// Иконка окна/панели задач. 15 пресетов + custom + default.
pub fn apply_app_icon(app: &AppHandle, icon_id: &str) {
    let id = normalize_app_icon(icon_id);
    let icon: tauri::image::Image<'_> = if id == "custom" {
        let Some(path) = custom_app_icon_path(app) else { return };
        match tauri::image::Image::from_path(&path) {
            Ok(img) => img,
            Err(_) => tauri::include_image!("icons/icon.png"),
        }
    } else {
        match id {
            "classic" => tauri::include_image!("icons/presets/classic/icon.png"),
            "darkEdge" => tauri::include_image!("icons/presets/darkEdge/icon.png"),
            "cyberGlow" => tauri::include_image!("icons/presets/cyberGlow/icon.png"),
            "materialLight" => tauri::include_image!("icons/presets/materialLight/icon.png"),
            "minimal" => tauri::include_image!("icons/presets/minimal/icon.png"),
            "purpleClassic" => tauri::include_image!("icons/presets/purpleClassic/icon.png"),
            "monochrome" => tauri::include_image!("icons/presets/monochrome/icon.png"),
            "classicRed" => tauri::include_image!("icons/presets/classicRed/icon.png"),
            "neon" => tauri::include_image!("icons/presets/neon/icon.png"),
            "cosmicOrbit" => tauri::include_image!("icons/presets/cosmicOrbit/icon.png"),
            "aquaWave" => tauri::include_image!("icons/presets/aquaWave/icon.png"),
            "armorPlate" => tauri::include_image!("icons/presets/armorPlate/icon.png"),
            "pixel" => tauri::include_image!("icons/presets/pixel/icon.png"),
            "lineArt" => tauri::include_image!("icons/presets/lineArt/icon.png"),
            "voidMatrix" => tauri::include_image!("icons/presets/voidMatrix/icon.png"),
            _ => tauri::include_image!("icons/icon.png"),
        }
    };
    if let Some(win) = app.get_webview_window("main") {
        let _ = win.set_icon(icon);
    }
}

fn snapshot(app: &AppHandle, st: &Mutex<BrowserState>) -> AppState {
    let mut public = st.lock().unwrap().public_state();
    public.window = window_info_from_app(app);
    public
}

#[tauri::command]
pub fn state(app: AppHandle, st: Browser<'_>) -> Result<AppState, String> {
    Ok(snapshot(&app, &st))
}

#[tauri::command]
pub async fn create_tab(
    app: AppHandle,
    url: Option<String>,
    background: Option<bool>,
) -> Result<u32, String> {
    tabs::create_tab(&app, url, background.unwrap_or(false))
}

#[tauri::command]
pub async fn close_tab(app: AppHandle, id: u32) -> Result<(), String> {
    tabs::close_tab(&app, id)
}

#[tauri::command]
pub async fn select_tab(app: AppHandle, id: u32) -> Result<(), String> {
    tabs::select_tab(&app, id)
}

#[tauri::command]
pub async fn reopen_tab(app: AppHandle) -> Result<(), String> {
    tabs::reopen_tab(&app)
}

#[tauri::command]
pub async fn navigate(app: AppHandle, id: u32, url: String) -> Result<(), String> {
    tabs::navigate(&app, id, &url)
}

#[tauri::command]
pub async fn nav(app: AppHandle, action: String) -> Result<(), String> {
    tabs::nav(&app, &action)
}

#[tauri::command]
pub fn set_zoom(app: AppHandle, delta: String) -> Result<(), String> {
    tabs::set_zoom(&app, &delta)
}

#[tauri::command]
pub fn toggle_devtools(app: AppHandle) -> Result<(), String> {
    let label = {
        let st = app.state::<Mutex<BrowserState>>();
        let s = st.lock().unwrap();
        s.active_id.and_then(|id| s.find(id).map(|t| t.label.clone()))
    };
    if let Some(label) = label {
        if let Some(wv) = app.get_webview(&label) {
            if DEVTOOLS_OPENED.swap(true, Ordering::SeqCst) {
                tabs::emit_toast(&app, "DevTools уже открыты");
                return Ok(());
            }
            wv.open_devtools();
            return Ok(());
        }
    }
    tabs::emit_toast(&app, "Нет активной вкладки");
    Ok(())
}

/// Хоткеи, пришедшие из дочернего webview вкладки. Сама страница не может
/// дотянуться до хрома, поэтому действие выполняем здесь, от имени браузера.
/// Команду видит и внешний сайт внутри вкладки, поэтому аргументы проверяем
/// строгим списком — в `eval` не попадает ничего, кроме наших констант.
#[tauri::command]
pub fn webview_shortcut(app: AppHandle, action: String, arg: Option<String>) -> Result<(), String> {
    match action.as_str() {
        "nav" => {
            let a = arg.as_deref().unwrap_or("reload");
            if !matches!(a, "back" | "forward" | "reload" | "hard-reload" | "stop") {
                return Ok(());
            }
            tabs::nav(&app, a)?;
        }
        "devtools" => toggle_devtools(app)?,
        "fullscreen" => {
            if let Some(w) = app.get_webview_window("main") {
                let next = !w.is_fullscreen().unwrap_or(false);
                let _ = w.set_fullscreen(next);
            }
        }
        "new-tab" => {
            tabs::create_tab(&app, None, false)?;
        }
        "reopen-tab" => tabs::reopen_tab(&app)?,
        "close-tab" => {
            let id = {
                let st = app.state::<Mutex<BrowserState>>();
                let active = st.lock().map_err(|e| e.to_string())?.active_id;
                active
            };
            if let Some(id) = id {
                tabs::close_tab(&app, id)?;
            }
        }
        "zoom" => {
            let d = arg.as_deref().unwrap_or("");
            if !matches!(d, "0.1" | "-0.1" | "reset") {
                return Ok(());
            }
            tabs::set_zoom(&app, d)?;
        }
        "cycle-tab" => {
            let dir: i64 = match arg.as_deref() {
                Some("-1") => -1,
                Some("1") => 1,
                _ => return Ok(()),
            };
            let id = {
                let st = app.state::<Mutex<BrowserState>>();
                let s = st.lock().map_err(|e| e.to_string())?;
                if s.tabs.is_empty() {
                    return Ok(());
                }
                let current = s
                    .active_id
                    .and_then(|id| s.tabs.iter().position(|t| t.info.id == id))
                    .unwrap_or(0);
                let next = (current as i64 + dir).rem_euclid(s.tabs.len() as i64) as usize;
                s.tabs[next].info.id
            };
            tabs::select_tab(&app, id)?;
        }
        "select-tab-index" => {
            let index = match arg.as_deref().and_then(|a| a.parse::<usize>().ok()) {
                Some(n) if (1..=9).contains(&n) => n - 1,
                _ => return Ok(()),
            };
            let id = {
                let st = app.state::<Mutex<BrowserState>>();
                let s = st.lock().map_err(|e| e.to_string())?;
                match s.tabs.get(index) {
                    Some(t) => t.info.id,
                    None => return Ok(()),
                }
            };
            tabs::select_tab(&app, id)?;
        }
        "focus-omnibox" => {
            // Адресная строка живёт в основном webview — фокус и eval только там.
            let main = app
                .get_webview("main")
                .ok_or_else(|| "главный webview не найден".to_string())?;
            let _ = main.set_focus();
            let _ = main.eval("window.__ghostFocusOmnibox?.()");
        }
        _ => {}
    }
    Ok(())
}

#[tauri::command]
pub fn set_overlay(app: AppHandle, open: bool, st: Browser<'_>) -> Result<AppState, String> {
    {
        let mut s = st.lock().unwrap();
        s.settings_open = open;
        if open {
            s.downloads_open = false;
            s.ui_editor_open = false;
        }
    }
    // Модальное окно рисуется в основном webview — убираем вкладки с пути.
    tabs::layout_webviews(&app);
    Ok(snapshot(&app, &st))
}

#[tauri::command]
pub fn set_downloads(app: AppHandle, open: bool, st: Browser<'_>) -> Result<AppState, String> {
    {
        let mut s = st.lock().unwrap();
        s.downloads_open = open;
        if open {
            s.settings_open = false;
            s.ui_editor_open = false;
        }
    }
    tabs::layout_webviews(&app);
    Ok(snapshot(&app, &st))
}

/// Редактор UI — отдельная модалка: не мешает флагам настроек/загрузок.
#[tauri::command]
pub fn set_ui_editor(app: AppHandle, open: bool, st: Browser<'_>) -> Result<AppState, String> {
    {
        let mut s = st.lock().unwrap();
        s.ui_editor_open = open;
        if open {
            s.settings_open = false;
            s.downloads_open = false;
        }
    }
    tabs::layout_webviews(&app);
    Ok(snapshot(&app, &st))
}

#[tauri::command]
pub fn get_settings(app: AppHandle, st: Browser<'_>) -> Result<Settings, String> {
    // Подтягиваем изменения, сделанные другим экземпляром/вне приложения.
    // Держим лок на время сравнения, чтобы параллельная команда не потерялась.
    let saved = load_settings(&app);
    let (settings, changed) = {
        let mut s = st.lock().map_err(|e| e.to_string())?;
        let changed = saved.scheme != s.settings.scheme
            || saved.accent != s.settings.accent
            || saved.search_engine != s.settings.search_engine
            || saved.download_path != s.settings.download_path
            || saved.ui_theme != s.settings.ui_theme
            || saved.dialog_style != s.settings.dialog_style
            || saved.language != s.settings.language
            || saved.saturation != s.settings.saturation
            || saved.cursor_preset != s.settings.cursor_preset
            || saved.sounds != s.settings.sounds
            || saved.app_icon != s.settings.app_icon;
        if changed {
            s.settings = saved;
        }
        (s.settings.clone(), changed)
    };
    // get_settings тоже должен обновлять домашнюю вкладку — иначе она
    // может жить со старыми настройками до следующего apply_settings.
    emit_settings(&app, &settings);
    if changed {
        let accent = settings.accent.clone().unwrap_or_else(system_accent);
        tabs::apply_cursor(
            &app,
            &accent_with_saturation(&accent, settings.saturation),
            &settings.cursor_preset,
        );
        apply_app_icon(&app, &settings.app_icon);
    }
    Ok(settings)
}

// ── полный редактор UI (P0) ────────────────────────────────────────────────

/// Защита settings.json от битых/старых пресетов. Полный список токенов и
/// диапазоны живут на фронтенде; здесь проверяем форму и разумные лимиты.
fn validate_ui_theme(theme: &UiTheme) -> Result<(), String> {
    if theme.version != 1 {
        return Err(format!("неизвестная версия пресета UI: {}", theme.version));
    }
    if theme.overrides.len() > 128 {
        return Err("слишком много правок UI (максимум 128)".into());
    }
    for (key, value) in &theme.overrides {
        if key.is_empty()
            || key.len() > 64
            || !key.chars().all(|c| c.is_ascii_alphanumeric() || c == '-' || c == '_')
        {
            return Err(format!("недопустимое имя токена UI: {key}"));
        }
        match value.as_f64() {
            Some(n) if n.is_finite() && n.abs() <= 10_000.0 => {}
            _ => return Err(format!("недопустимое значение токена {key}")),
        }
    }
    let size = serde_json::to_string(theme).map_err(|e| e.to_string())?.len();
    if size > 32 * 1024 {
        return Err("пресет UI слишком большой (максимум 32 КБ)".into());
    }
    Ok(())
}

fn store_ui_theme(app: &AppHandle, st: Browser<'_>, theme: UiTheme) -> Result<UiTheme, String> {
    validate_ui_theme(&theme)?;
    {
        let mut s = st.lock().map_err(|e| e.to_string())?;
        s.settings.ui_theme = theme.clone();
        save_settings(app, &s.settings);
    }
    let _ = app.emit("ghost://ui-theme", &theme);
    Ok(theme)
}

#[tauri::command]
pub fn get_ui_theme(app: AppHandle, st: Browser<'_>) -> Result<UiTheme, String> {
    let saved = load_settings(&app).ui_theme;
    if saved != st.lock().map_err(|e| e.to_string())?.settings.ui_theme {
        st.lock().map_err(|e| e.to_string())?.settings.ui_theme = saved.clone();
    }
    Ok(saved)
}

#[tauri::command]
pub fn set_ui_theme(app: AppHandle, preset: UiTheme, st: Browser<'_>) -> Result<UiTheme, String> {
    store_ui_theme(&app, st, preset)
}

#[tauri::command]
pub fn reset_ui_theme(app: AppHandle, st: Browser<'_>) -> Result<UiTheme, String> {
    store_ui_theme(&app, st, UiTheme::default())
}

#[tauri::command]
pub fn apply_settings(
    app: AppHandle,
    patch: SettingsPatch,
    st: Browser,
) -> Result<AppState, String> {
    {
        let mut s = st.lock().unwrap();
        if let Some(scheme) = patch.scheme {
            s.settings.scheme = scheme;
        }
        if let Some(accent) = patch.accent {
            s.settings.accent = accent;
        }
        if let Some(engine) = patch.search_engine {
            s.settings.search_engine = engine;
        }
        if let Some(path) = patch.download_path {
            s.settings.download_path = path;
        }
        if let Some(style) = patch.dialog_style {
            // Неизвестное значение просто игнорируем — старые/битые настройки
            // не должны ломать стиль модалок.
            if matches!(style.as_str(), "pattern" | "fullscreen" | "panel") {
                s.settings.dialog_style = normalize_dialog_style(&style).into();
            }
        }
        if let Some(language) = patch.language {
            s.settings.language = normalize_language(&language).into();
        }
        if let Some(saturation) = patch.saturation {
            s.settings.saturation = normalize_saturation(&saturation);
        }
        if let Some(preset) = patch.cursor_preset {
            s.settings.cursor_preset = normalize_cursor_preset(&preset).into();
        }
        if let Some(sounds) = patch.sounds {
            s.settings.sounds = sounds;
        }
        if let Some(icon) = patch.app_icon {
            s.settings.app_icon = normalize_app_icon(&icon).into();
        }
        save_settings(&app, &s.settings);
    }
    // Домашняя вкладка — отдельный webview. Шлём ей живые настройки, чтобы
    // тема/акцент/поисковик менялись без пересоздания вкладки.
    let settings = st.lock().unwrap().settings.clone();
    let accent = settings.accent.clone().unwrap_or_else(system_accent);
    emit_settings(&app, &settings);
    // Сайты в дочерних webview не слышат Tauri-события — обновляем их курсор
    // напрямую. Лок state уже отпущен: eval не блокирует настройки.
    tabs::apply_cursor(
        &app,
        &accent_with_saturation(&accent, settings.saturation),
        &settings.cursor_preset,
    );
    apply_app_icon(&app, &settings.app_icon);
    tabs::emit_state(&app);
    Ok(snapshot(&app, &st))
}

/// Фон новой вкладки лежит в localStorage общего origin, но дочерние WebView2
/// не получают `storage`/BroadcastChannel от главного webview. Шлём событие
/// через Tauri — так фон обновляется сразу и в настоящем приложении.
#[tauri::command]
pub fn notify_wallpaper(app: AppHandle, action: String) -> Result<(), String> {
    if action != "update" && action != "clear" {
        return Err("неизвестное действие фона".into());
    }
    let _ = app.emit("ghost://wallpaper", action);
    Ok(())
}

#[tauri::command]
pub fn set_chrome_height(app: AppHandle, height: f64) -> Result<(), String> {
    tabs::set_chrome_height(&app, height);
    Ok(())
}

// ---- Загрузки -------------------------------------------------------------

// ── реальные загрузки WebView2 ──────────────────────────────────────────────

fn download_path(st: &Browser<'_>, id: &str) -> Option<String> {
    st.lock()
        .ok()?
        .downloads
        .iter()
        .find(|d| d.id == id)
        .map(|d| d.save_path.clone())
}

#[tauri::command]
pub fn get_downloads(st: Browser<'_>) -> Result<Vec<DownloadItem>, String> {
    Ok(st.lock().unwrap().downloads.clone())
}

#[tauri::command]
pub fn clear_downloads(app: AppHandle, st: Browser<'_>) -> Result<(), String> {
    st.lock().unwrap().downloads.clear();
    crate::downloads::emit(&app);
    Ok(())
}

#[tauri::command]
pub fn remove_download(app: AppHandle, id: String, st: Browser<'_>) -> Result<(), String> {
    st.lock().unwrap().downloads.retain(|d| d.id != id);
    crate::downloads::emit(&app);
    Ok(())
}

#[tauri::command]
pub fn open_download(id: String, st: Browser<'_>) -> Result<(), String> {
    let path = download_path(&st, &id).ok_or_else(|| "Загрузка не найдена".to_string())?;
    if !Path::new(&path).is_file() {
        return Err(format!("Файл не найден: {path}"));
    }
    std::process::Command::new("explorer.exe")
        .arg(&path)
        .spawn()
        .map_err(|e| format!("Не удалось открыть файл: {e}"))?;
    Ok(())
}

#[tauri::command]
pub fn show_download_in_folder(id: String, st: Browser<'_>) -> Result<(), String> {
    let path = download_path(&st, &id).ok_or_else(|| "Загрузка не найдена".to_string())?;
    std::process::Command::new("explorer.exe")
        .arg(format!("/select,{path}"))
        .spawn()
        .map_err(|e| format!("Не удалось показать файл в папке: {e}"))?;
    Ok(())
}

#[tauri::command]
pub fn pause_download(app: AppHandle, id: String, st: Browser<'_>) -> Result<(), String> {
    {
        let mut s = st.lock().unwrap();
        let Some(item) = s.downloads.iter_mut().find(|d| d.id == id) else {
            return Err("Загрузка не найдена".into());
        };
        if item.state == "in-progress" {
            item.paused = Some(true);
        }
    }
    crate::downloads::emit(&app);
    Ok(())
}

#[tauri::command]
pub fn resume_download(app: AppHandle, id: String, st: Browser<'_>) -> Result<(), String> {
    {
        let mut s = st.lock().unwrap();
        let Some(item) = s.downloads.iter_mut().find(|d| d.id == id) else {
            return Err("Загрузка не найдена".into());
        };
        if item.state == "in-progress" {
            item.paused = Some(false);
        }
    }
    crate::downloads::emit(&app);
    Ok(())
}

#[tauri::command]
pub fn cancel_download(app: AppHandle, id: String, st: Browser<'_>) -> Result<(), String> {
    {
        let mut s = st.lock().unwrap();
        let Some(item) = s.downloads.iter_mut().find(|d| d.id == id) else {
            return Err("Загрузка не найдена".into());
        };
        if item.state == "in-progress" {
            item.state = "cancelled".to_string();
            item.paused = Some(false);
            item.end_time = Some(
                std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .map(|d| d.as_millis() as u64)
                    .unwrap_or(0),
            );
        }
    }
    crate::downloads::emit(&app);
    Ok(())
}

/// Нативный диалог выбора папки без дополнительных Tauri-плагинов.
#[tauri::command]
pub fn choose_download_dir() -> Result<Option<String>, String> {
    let script = r#"
Add-Type -AssemblyName System.Windows.Forms
$d = New-Object System.Windows.Forms.FolderBrowserDialog
$d.Description = 'Выберите папку для загрузок'
$d.ShowNewFolderButton = $true
if ($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { Write-Output $d.SelectedPath }
"#;
    let output = std::process::Command::new("powershell.exe")
        .args(["-NoProfile", "-STA", "-Command", script])
        .output()
        .map_err(|e| format!("Не удалось открыть диалог выбора папки: {e}"))?;
    let path = String::from_utf8_lossy(&output.stdout).trim().to_string();
    if path.is_empty() { Ok(None) } else { Ok(Some(path)) }
}

#[tauri::command]
pub fn open_downloads_folder(st: Browser<'_>) -> Result<String, String> {
    let path = st
        .lock()
        .unwrap()
        .settings
        .download_path
        .clone()
        .unwrap_or_else(|| {
            std::env::var("USERPROFILE").unwrap_or_else(|_| "C:\\".into()) + "\\Downloads"
        });

    if !Path::new(&path).is_dir() {
        return Err(format!("Папка не найдена: {path}"));
    }
    match std::process::Command::new("explorer.exe").arg(&path).spawn() {
        Ok(_) => Ok(format!("Открыта папка: {path}")),
        Err(e) => Err(format!("Не удалось открыть папку «{path}»: {e}")),
    }
}

// ── снимок страницы под модальным окном ─────────────────────────────────────

#[cfg(windows)]
#[repr(C)]
struct GbRect {
    left: i32,
    top: i32,
    right: i32,
    bottom: i32,
}

#[cfg(windows)]
extern "system" {
    fn GetWindowRect(hwnd: isize, rect: *mut GbRect) -> i32;
    fn GetForegroundWindow() -> isize;
    fn GetWindowThreadProcessId(hwnd: isize, pid: *mut u32) -> u32;
}

/// CopyFromScreen снимает всё, что физически лежит на экране. Если поверх
/// браузера открыт Chrome или чат, в снимок попадёт он. Смотрим процесс
/// активного окна: так надёжно, даже когда фокус внутри дочернего webview.
#[cfg(windows)]
fn our_window_is_foreground() -> bool {
    let mut pid: u32 = 0;
    unsafe { GetWindowThreadProcessId(GetForegroundWindow(), &mut pid) };
    pid == std::process::id()
}

/// Сам тяжёлый кусок — запуск PowerShell (~1 секунда). Раньше это была
/// синхронная команда, и Tauri выполнял её на главном потоке: весь интерфейс
/// замирал, поэтому модалки открывались с задержкой. Теперь это отдельная
/// функция, которую мы зовём из spawn_blocking.
#[cfg(windows)]
fn capture_screen(x: i32, y: i32, w: i32, h: i32) -> Result<String, String> {
    use std::os::windows::process::CommandExt;

    // Вторая проверка — уже в фоновом потоке, перед самим запуском PowerShell.
    if !our_window_is_foreground() {
        return Err("окно не поверх других".into());
    }

    let script = format!(
        r#"
Add-Type -AssemblyName System.Drawing
$bmp = New-Object System.Drawing.Bitmap({w},{h})
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.CopyFromScreen({x},{y},0,0,$bmp.Size)
$ms = New-Object System.IO.MemoryStream
$bmp.Save($ms,[System.Drawing.Imaging.ImageFormat]::Png)
[Convert]::ToBase64String($ms.ToArray())
"#
    );
    // Параллельные открытия модалок не должны перезаписывать один и тот же
    // временный скрипт, пока PowerShell его ещё читает.
    let nanos = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    let path = std::env::temp_dir()
        .join(format!("ghost-page-snapshot-{}-{nanos}.ps1", std::process::id()));
    std::fs::write(&path, &script).map_err(|e| e.to_string())?;
    let output = std::process::Command::new("powershell.exe")
        .args([
            "-NoProfile",
            "-NonInteractive",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
        ])
        .arg(&path)
        .creation_flags(0x0800_0000) // CREATE_NO_WINDOW
        .output()
        .map_err(|e| e.to_string())?;

    let _ = std::fs::remove_file(&path);
    let b64 = String::from_utf8_lossy(&output.stdout).trim().to_string();
    if b64.is_empty() {
        return Err("не удалось снять страницу".into());
    }
    Ok(format!("data:image/png;base64,{b64}"))
}

/// На время диалога вкладки скрыты. Снимем область страницы заранее, чтобы за
/// полупрозрачным скримом было видно сайт, на котором пользователь был.
#[cfg(windows)]
#[tauri::command]
pub async fn capture_page(app: AppHandle, st: Browser<'_>) -> Result<String, String> {
    let window = app
        .get_window("main")
        .ok_or_else(|| "главное окно не найдено".to_string())?;
    // Свёрнутое окно даёт чёрный/чужой снимок — лучше сразу отказаться.
    if window.is_minimized().unwrap_or(false) {
        return Err("окно свёрнуто".into());
    }
    let hwnd = window.hwnd().map_err(|e| e.to_string())?;
    // Сразу отсекаем снимок, если поверх браузера сейчас другое окно.
    if !our_window_is_foreground() {
        return Err("окно не поверх других".into());
    }

    let (chrome, scale) = {
        let s = st.lock().map_err(|e| e.to_string())?;
        let scale = window.scale_factor().unwrap_or(1.0);
        (s.chrome_height, scale)
    };

    let mut rect = GbRect {
        left: 0,
        top: 0,
        right: 0,
        bottom: 0,
    };
    if unsafe { GetWindowRect(hwnd.0 as isize, &mut rect) } == 0 {
        return Err("не удалось измерить окно".into());
    }
    let chrome_px = (chrome * scale).round() as i32;
    let x = rect.left;
    let y = rect.top + chrome_px;
    let w = rect.right - rect.left;
    let h = rect.bottom - rect.top - chrome_px;
    if w <= 0 || h <= 0 {
        return Err("неверный размер страницы".into());
    }

    // Всё медленное — в пуле потоков: главный поток остаётся свободным и
    // кнопки модалок открываются без задержки.
    tauri::async_runtime::spawn_blocking(move || capture_screen(x, y, w, h))
        .await
        .map_err(|e| e.to_string())?
}

#[tauri::command]
pub fn get_custom_app_icon(app: AppHandle) -> Result<Option<String>, String> {
    let Some(path) = custom_app_icon_path(&app) else { return Ok(None) };
    let bytes = match std::fs::read(&path) {
        Ok(b) => b,
        Err(_) => return Ok(None),
    };
    let b64 = general_purpose::STANDARD.encode(bytes);
    Ok(Some(format!("data:image/png;base64,{b64}")))
}

#[tauri::command]
pub fn save_custom_app_icon(
    app: AppHandle,
    st: Browser<'_>,
    data_url: String,
) -> Result<Settings, String> {
    let raw = data_url.trim();
    let b64 = raw
        .split_once(',')
        .map(|(_, b)| b)
        .unwrap_or(raw);
    let bytes = general_purpose::STANDARD
        .decode(b64.trim())
        .map_err(|e| format!("bad icon data: {e}"))?;
    // Validate it's an image before saving.
    let _ = tauri::image::Image::from_bytes(&bytes).map_err(|e| format!("bad icon image: {e}"))?;
    let path = custom_app_icon_path(&app).ok_or("no app config dir")?;
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    std::fs::write(&path, &bytes).map_err(|e| e.to_string())?;

    let settings = {
        let mut s = st.lock().map_err(|e| e.to_string())?;
        s.settings.app_icon = "custom".to_string();
        let snapshot = s.settings.clone();
        let _ = save_settings(&app, &snapshot);
        snapshot
    };
    apply_app_icon(&app, "custom");
    emit_settings(&app, &settings);
    Ok(settings)
}

#[cfg(not(windows))]
#[tauri::command]
pub async fn capture_page() -> Result<String, String> {
    Err("Скриншот страницы доступен только в Windows".into())
}
