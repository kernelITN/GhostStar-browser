/**
 * Пресет правок UI: валидация, генерация CSS и «разреженность».
 *
 * В(settings.json)/(localStorage) лежит ТОЛЬКО то, что пользователь изменил.
 * Если значение совпало с дефолтом — оно удаляется. Поэтому «Сброс» всегда
 * возвращает исходный дизайн, даже если в конфиге что-то осталось старое.
 */
import type { UiOverrides, UiPreset, UiTokenId } from '../../../shared/types'
import {
  formatTokenValue,
  isCustomValue,
  TOKEN_BY_ID,
  TOKEN_REGISTRY,
} from './token-schema'

const STORAGE_KEY = 'ghostmaterial:ui-theme'
const MAX_PRESET_BYTES = 32 * 1024

export function emptyPreset(): UiPreset {
  return { version: 1, overrides: {} }
}

export function clonePreset(preset: UiPreset): UiPreset {
  return { version: 1, overrides: { ...preset.overrides } }
}

export function presetsEqual(a: UiPreset, b: UiPreset): boolean {
  const keysA = Object.keys(a.overrides) as UiTokenId[]
  const keysB = Object.keys(b.overrides) as UiTokenId[]
  if (keysA.length !== keysB.length) return false
  return keysA.every((key) => a.overrides[key] === b.overrides[key])
}

/**
 * Принимает что угодно (settings.json, URL-параметр, localStorage) и возвращает
 * безопасный пресет. Незнакомые ключи игнорируются, числа клампятся по реестру.
 */
export function sanitizePreset(raw: unknown): UiPreset {
  if (!raw || typeof raw !== 'object') return emptyPreset()
  const source = raw as { version?: unknown; overrides?: unknown }
  if (source.version !== 1) return emptyPreset()
  if (!source.overrides || typeof source.overrides !== 'object') return emptyPreset()

  const overrides: UiOverrides = {}
  const entries = Object.entries(source.overrides as Record<string, unknown>)
  if (entries.length > 128) return emptyPreset()

  for (const [key, value] of entries) {
    const def = TOKEN_BY_ID.get(key as UiTokenId)
    if (!def || typeof value !== 'number' || !Number.isFinite(value)) continue
    const clamped = Math.min(def.max, Math.max(def.min, value))
    if (isCustomValue(def.id, clamped)) overrides[def.id] = clamped
  }

  const preset: UiPreset = { version: 1, overrides }
  try {
    if (JSON.stringify(preset).length > MAX_PRESET_BYTES) return emptyPreset()
  } catch {
    return emptyPreset()
  }
  return preset
}

/** CSS только с пользовательскими правками — дефолты не записываем. */
export function presetToCssText(preset: UiPreset): string {
  const lines: string[] = []
  for (const token of TOKEN_REGISTRY) {
    if (!token.cssVar) continue
    const value = preset.overrides[token.id]
    if (value === undefined || !isCustomValue(token.id, value)) continue
    lines.push(`  ${token.cssVar}: ${formatTokenValue(token, value)};`)
  }
  return lines.length ? `:root {\n${lines.join('\n')}\n}` : ''
}

/** Атрибуты для md-progress-indicator — только явные правки. */
export function presetToWaveAttrs(preset: UiPreset): Record<string, string> {
  const attrs: Record<string, string> = {}
  for (const token of TOKEN_REGISTRY) {
    if (!token.waveAttr) continue
    const value = preset.overrides[token.id]
    if (value === undefined || !isCustomValue(token.id, value)) continue
    attrs[token.waveAttr] = String(value)
  }
  return attrs
}

export function loadLocalPreset(): UiPreset {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    return raw ? sanitizePreset(JSON.parse(raw)) : emptyPreset()
  } catch {
    return emptyPreset()
  }
}

export function saveLocalPreset(preset: UiPreset): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(sanitizePreset(preset)))
  } catch {
    /* приватный режим — живём без сохранения */
  }
}
