#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    ghoststar_browser_lib::run()
}
