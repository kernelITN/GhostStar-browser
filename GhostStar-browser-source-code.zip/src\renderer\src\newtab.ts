import '@materialwebunofficial/md3e-web/tokens.css'
import '@materialwebunofficial/md3e-web/components/md-theme.js'
import { singleAccentPalette } from './theme-palette'

const theme = document.getElementById('theme')
if (!theme) throw new Error('md-theme не найден')

const params = new URLSearchParams(window.location.search)
const rawScheme = params.get('scheme')
const scheme =
  rawScheme === 'light' || rawScheme === 'dark'
    ? rawScheme
    : window.matchMedia('(prefers-color-scheme: dark)').matches
      ? 'dark'
      : 'light'

const rawAccent = params.get('accent') ?? ''
const accent = /^#[0-9a-f]{6}$/i.test(rawAccent) ? rawAccent : '#6a4bd8'

theme.setAttribute('scheme', 'expressive')
theme.setAttribute('palette-variant', 'expressive')
theme.setAttribute('motion-scheme', 'expressive')
theme.setAttribute('color-mode', scheme)
theme.setAttribute('primary-seed', accent)
theme.setAttribute(
  'custom-palette',
  JSON.stringify(singleAccentPalette(accent, scheme === 'dark')),
)
document.documentElement.dataset.scheme = scheme
document.documentElement.style.colorScheme = scheme
