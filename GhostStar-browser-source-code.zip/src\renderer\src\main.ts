import './tauri-bridge'
import '@materialwebunofficial/md3e-web/tokens.css'
import '@materialwebunofficial/md3e-web/components/md-theme.js'
import '@materialwebunofficial/md3e-web/components/md-icon-button.js'
import '@materialwebunofficial/md3e-web/components/md-search-bar.js'
import '@materialwebunofficial/md3e-web/components/md-chip.js'
import '@materialwebunofficial/md3e-web/components/md-button.js'
import '@materialwebunofficial/md3e-web/components/md-dialog.js'
import '@materialwebunofficial/md3e-web/components/md-progress-indicator.js'
import '@materialwebunofficial/md3e-web/components/md-snackbar.js'
import './styles.css'

import { singleAccentPalette } from './theme-palette'
import type {
  AppState,
  DownloadItem,
  GhostApi,
  SettingsPatch,
  SettingsSync,
} from '../../shared/types'

declare global {
  interface Window {
    __ghostFocusOmnibox?: (select?: boolean) => void
  }
}

type ChipEl = HTMLElement & { selected: boolean }
type DialogEl = HTMLElement & { open: boolean; show(): void; close(): void }
type TextFieldEl = HTMLElement & { value: string }
type SnackbarEl = HTMLElement & { show?: (message: string) => void }

const $ = <T extends HTMLElement = HTMLElement>(selector: string): T => {
  const el = document.querySelector<T>(selector)
  if (!el) throw new Error(`Элемент ${selector} не найден`)
  return el
}

const api = window.ghost

const themeEl = $<HTMLElement>('#theme')
const chromeEl = $<HTMLElement>('#chrome')
const tabsEl = $<HTMLElement>('#tabs')
const omnibox = $<TextFieldEl>('#omnibox')
const omniLeading = $<HTMLElement>('#omni-leading')
const btnBack = $<HTMLElement>('#btn-back')
const btnForward = $<HTMLElement>('#btn-forward')
const btnReload = $<HTMLElement>('#btn-reload')
const pageProgress = $<HTMLElement>('#page-progress')
const btnDownloads = $<HTMLElement>('#btn-downloads')

const downloadsPanel = $<DialogEl>('#downloads')
const downloadsList = $<HTMLElement>('#downloads-list')
const downloadsEmpty = $<HTMLElement>('#downloads-empty')
const downloadsClear = $<HTMLElement>('#downloads-clear')
const settingsPanel = $<DialogEl>('#settings')
const schemeRow = $<HTMLElement>('#scheme-row')
const accentRow = $<HTMLElement>('#accent-row')
const accentSystem = $<ChipEl>('#accent-system')
const snackbar = $<SnackbarEl>('#gb-snack')

const ACCENTS = [
  '#6a4bd8',
  '#006a6a',
  '#0061a4',
  '#8e4585',
  '#b3261e',
  '#e53935',
  '#720601',
  '#386a20',
  '#7d5260',
  '#f4511e',
  '#0b57d0',
  '#c58b00',
]

let state: AppState | null = null
let currentScheme: 'auto' | 'light' | 'dark' = 'auto'
let currentAccent = '#6a4bd8'
let downloads: DownloadItem[] = []
let settingsOpen = false
let downloadsOpen = false
let settingsSeq = 0

const darkMedia = window.matchMedia('(prefers-color-scheme: dark)')

function showToast(message: string): void {
  if (snackbar.show) snackbar.show(message)
  else console.log('[toast]', message)
}

function callAction(promise: Promise<unknown>, label: string): void {
  void promise.catch((error) => showToast(`${label}: ${error}`))
}

function activeTab() {
  if (!state) return null
  return state.tabs.find((tab) => tab.id === state!.activeId) ?? null
}

// ── тема ──────────────────────────────────────────────────────────────────

function effectiveScheme(): 'light' | 'dark' {
  const scheme = state?.theme.scheme ?? currentScheme
  return scheme === 'auto' ? (darkMedia.matches ? 'dark' : 'light') : scheme
}

function effectiveAccent(): string {
  return state?.theme.accent || currentAccent || '#6a4bd8'
}

function applyTheme(): void {
  const scheme = effectiveScheme()
  const accent = effectiveAccent()
  themeEl.setAttribute('scheme', 'expressive')
  themeEl.setAttribute('palette-variant', 'expressive')
  themeEl.setAttribute('motion-scheme', 'expressive')
  themeEl.setAttribute('color-mode', scheme)
  themeEl.setAttribute('primary-seed', accent)
  themeEl.setAttribute(
    'custom-palette',
    JSON.stringify(singleAccentPalette(accent, scheme === 'dark')),
  )
  document.documentElement.dataset.scheme = scheme
  document.documentElement.style.colorScheme = scheme
}

darkMedia.addEventListener('change', () => applyTheme())

// ── вкладки и хром ────────────────────────────────────────────────────────

function renderTabs(): void {
  if (!state) return
  const scroll = tabsEl.scrollLeft
  const nodes = state.tabs.map((tab) => {
    const el = document.createElement('div')
    el.className = 'tab'
    el.dataset.id = String(tab.id)
    el.setAttribute('role', 'tab')
    el.setAttribute('aria-selected', tab.id === state!.activeId ? 'true' : 'false')
    el.classList.toggle('active', tab.id === state!.activeId)
    el.title = tab.title

    const favicon = document.createElement('div')
    favicon.className = 'tab-favicon'
    favicon.textContent = tab.loading ? '◌' : '⎘'

    const title = document.createElement('span')
    title.className = 'tab-title'
    title.textContent = tab.title

    const close = document.createElement('button')
    close.className = 'tab-close'
    close.type = 'button'
    close.title = 'Закрыть вкладку'
    close.setAttribute('aria-label', 'Закрыть вкладку')
    close.textContent = '✕'
    close.addEventListener('click', (event) => {
      event.stopPropagation()
      callAction(api.invoke.closeTab(tab.id), 'Закрыть вкладку')
    })

    el.append(favicon, title, close)
    el.addEventListener('click', () => void api.invoke.selectTab(tab.id))
    el.addEventListener('auxclick', (event) => {
      if (event.button === 1) {
        event.preventDefault()
        callAction(api.invoke.closeTab(tab.id), 'Закрыть вкладку')
      }
    })
    return el
  })
  tabsEl.replaceChildren(...nodes)
  tabsEl.scrollLeft = scroll
}

function focusOmnibox(select = true): void {
  omnibox.focus()
  if (select) {
    requestAnimationFrame(() => {
      omnibox.shadowRoot?.querySelector<HTMLInputElement>('input')?.select()
    })
  }
}

window.__ghostFocusOmnibox = focusOmnibox

function renderToolbar(): void {
  const tab = activeTab()
  const focused = document.activeElement === omnibox || !!omnibox.shadowRoot?.activeElement
  if (!focused) omnibox.value = tab?.displayUrl ?? ''
  btnBack.toggleAttribute('disabled', !tab?.canGoBack)
  btnForward.toggleAttribute('disabled', !tab?.canGoForward)
  const loading = tab?.loading ?? false
  btnReload.setAttribute('icon', loading ? 'close' : 'refresh')
  btnReload.title = loading ? 'Остановить' : 'Обновить'
  pageProgress.hidden = !loading
  const url = tab?.url ?? ''
  omniLeading.textContent = !url ? 'search' : url.startsWith('https://') ? 'lock' : 'link'
}

function measureChrome(): void {
  const height = chromeEl.hidden ? 0 : Math.round(chromeEl.getBoundingClientRect().height)
  document.documentElement.style.setProperty('--chrome-h', `${height}px`)
  api.setChromeHeight(height)
}

function renderWindow(): void {
  if (!state) return
  const button = $<HTMLElement>('#win-max')
  const icon = document.querySelector<SVGElement>('#win-max-icon')
  if (!icon) throw new Error('Элемент #win-max-icon не найден')
  if (state.window.maximized) {
    button.title = 'Восстановить'
    icon.innerHTML =
      '<rect x="2.2" y="3.8" width="6" height="6" rx="1" /><path d="M4.2 3.8V2.6h5.2v5.2H8.2" />'
  } else {
    button.title = 'Развернуть'
    icon.innerHTML = '<rect x="2.2" y="2.2" width="7.6" height="7.6" rx="1.1" />'
  }
  chromeEl.hidden = state.window.fullscreen
  measureChrome()
}

function applyState(next: AppState): void {
  state = next
  applyTheme()
  renderTabs()
  renderToolbar()
  renderWindow()
}

// ── загрузки ──────────────────────────────────────────────────────────────

function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes < 0) return '—'
  if (bytes === 0) return '0 Б'
  const units = ['Б', 'КБ', 'МБ', 'ГБ']
  let value = bytes
  let unit = 0
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024
    unit += 1
  }
  return `${value >= 10 || unit === 0 ? Math.round(value) : value.toFixed(1)} ${units[unit]}`
}

function downloadPercent(item: DownloadItem): number {
  if (!item.totalBytes) return 0
  return Math.max(0, Math.min(100, Math.round((item.receivedBytes / item.totalBytes) * 100)))
}

function downloadMeta(item: DownloadItem): string {
  if (item.state === 'in-progress') {
    if (item.totalBytes) {
      return `${formatBytes(item.receivedBytes)} / ${formatBytes(item.totalBytes)} • ${downloadPercent(item)}%`
    }
    return `${formatBytes(item.receivedBytes)} • загрузка…`
  }
  if (item.state === 'completed') return formatBytes(item.receivedBytes || item.totalBytes || 0)
  if (item.state === 'cancelled') return 'Отменено'
  return 'Ошибка'
}

function textButton(label: string, onClick: () => void): HTMLElement {
  const button = document.createElement('md-button')
  button.setAttribute('variant', 'text')
  button.setAttribute('size', 's')
  button.setAttribute('label', label)
  button.title = label
  button.addEventListener('click', onClick)
  return button
}

function buildDownloadItem(item: DownloadItem): HTMLElement {
  const row = document.createElement('div')
  row.className = 'dl-item'
  row.dataset.state = item.state
  row.dataset.id = item.id

  const icon = document.createElement('div')
  icon.className = 'dl-item-icon'
  icon.innerHTML = '<span class="material-symbols-outlined">download</span>'

  const body = document.createElement('div')
  body.className = 'dl-item-body'
  const name = document.createElement('div')
  name.className = 'dl-item-name'
  name.textContent = item.filename
  const meta = document.createElement('div')
  meta.className = 'dl-item-meta'
  meta.textContent = downloadMeta(item)
  body.append(name, meta)

  const actions = document.createElement('div')
  actions.className = 'dl-item-actions'
  if (item.state === 'completed') {
    actions.append(
      textButton('Открыть', () => callAction(api.invoke.openDownload(item.id), 'Открыть')),
      textButton('В папке', () => callAction(api.invoke.showDownloadInFolder(item.id), 'Открыть папку')),
    )
  }
  actions.append(
    textButton('Удалить', () => callAction(api.invoke.removeDownload(item.id), 'Удалить')),
  )

  row.append(icon, body, actions)

  if (item.state === 'in-progress') {
    const progress = document.createElement('div')
    progress.className = 'dl-item-progress'
    const indicator = document.createElement('md-progress-indicator')
    indicator.setAttribute('type', 'linear')
    indicator.setAttribute('variant', 'wavy')
    if (item.totalBytes) indicator.setAttribute('value', String(downloadPercent(item)))
    else indicator.setAttribute('indeterminate', '')
    progress.append(indicator)
    row.append(progress)
  }
  return row
}

function updateDownloadButton(): void {
  const active = downloads.filter((item) => item.state === 'in-progress')
  btnDownloads.classList.toggle('is-active', active.length > 0)
  const known = active.filter((item) => item.totalBytes)
  btnDownloads.classList.toggle('is-indeterminate', active.length > 0 && known.length === 0)
  const received = known.reduce((sum, item) => sum + item.receivedBytes, 0)
  const total = known.reduce((sum, item) => sum + (item.totalBytes ?? 0), 0)
  btnDownloads.style.setProperty('--dl-progress', String(total ? Math.min(1, received / total) : 0))
}

async function refreshDownloads(): Promise<void> {
  try {
    downloads = await api.invoke.getDownloads()
    renderDownloads()
  } catch (error) {
    showToast(`Не удалось загрузить список: ${error}`)
  }
}

function renderDownloads(): void {
  const hasItems = downloads.length > 0
  downloadsEmpty.hidden = hasItems
  downloadsEmpty.classList.toggle('is-visible', !hasItems)
  downloadsClear.toggleAttribute('disabled', !hasItems)
  downloadsPanel.setAttribute(
    'supporting-text',
    hasItems ? `Файлов: ${downloads.length}` : 'Файлы, скачанные в этом окне',
  )
  downloadsList.replaceChildren(...downloads.map(buildDownloadItem))
  updateDownloadButton()
}

function openDownloads(): void {
  if (settingsOpen) {
    settingsOpen = false
    settingsPanel.close()
  }
  downloadsOpen = true
  downloadsPanel.show()
  void api.invoke.setOverlay(false)
  void api.invoke.setDownloads(true)
  void refreshDownloads()
}

function closeDownloads(): void {
  if (!downloadsOpen && !downloadsPanel.open) return
  downloadsOpen = false
  downloadsPanel.close()
  void api.invoke.setDownloads(false)
}

// ── настройки ─────────────────────────────────────────────────────────────

async function refreshPrefs(): Promise<void> {
  const settings = await api.invoke.getSettings()
  currentScheme = settings.scheme
  currentAccent = settings.accent ?? '#6a4bd8'
  renderPrefs()
  applyTheme()
}

function renderPrefs(): void {
  for (const chip of schemeRow.querySelectorAll<ChipEl>('[data-scheme]')) {
    chip.selected = chip.dataset.scheme === currentScheme
  }
  for (const swatch of accentRow.querySelectorAll<HTMLElement>('[data-accent]')) {
    swatch.classList.toggle('selected', swatch.dataset.accent === currentAccent)
  }
  accentSystem.selected = !currentAccent
  const input = accentRow.querySelector<HTMLInputElement>('input[type="color"]')
  if (input) input.value = currentAccent
}

async function applySettings(patch: SettingsPatch): Promise<void> {
  const seq = ++settingsSeq
  const next = await api.invoke.applySettings(patch)
  if (seq !== settingsSeq) return
  applyState(next)
  await refreshPrefs()
}

function buildSettings(): void {
  for (const hex of ACCENTS) {
    const button = document.createElement('button')
    button.className = 'swatch'
    button.type = 'button'
    button.dataset.accent = hex
    button.style.background = hex
    button.title = hex
    button.setAttribute('aria-label', `Акцент ${hex}`)
    button.addEventListener('click', () => void callAction(applySettings({ accent: hex }), 'Не удалось применить цвет'))
    accentRow.append(button)
  }

  const custom = document.createElement('label')
  custom.className = 'swatch'
  custom.title = 'Свой цвет'
  custom.style.background =
    'conic-gradient(#ff5f57, #febc2e, #28c840, #40a9ff, #a259ff, #ff5f57)'
  const input = document.createElement('input')
  input.type = 'color'
  input.value = currentAccent
  input.style.position = 'absolute'
  input.style.opacity = '0'
  input.style.width = '100%'
  input.style.height = '100%'
  input.style.cursor = 'pointer'
  input.addEventListener('change', () =>
    void callAction(applySettings({ accent: input.value }), 'Не удалось применить цвет'),
  )
  custom.append(input)
  accentRow.append(custom)

  accentSystem.addEventListener('click', () =>
    void callAction(applySettings({ accent: null }), 'Не удалось применить цвет'),
  )
  for (const chip of schemeRow.querySelectorAll<HTMLElement>('[data-scheme]')) {
    chip.addEventListener('click', () => {
      const scheme = chip.dataset.scheme as SettingsPatch['scheme']
      void callAction(applySettings({ scheme }), 'Не удалось применить тему')
    })
  }
}

function openSettings(): void {
  if (downloadsOpen) {
    downloadsOpen = false
    downloadsPanel.close()
  }
  settingsOpen = true
  settingsPanel.show()
  void api.invoke.setDownloads(false)
  void api.invoke.setOverlay(true)
  void refreshPrefs()
}

function closeSettings(): void {
  if (!settingsOpen && !settingsPanel.open) return
  settingsOpen = false
  settingsPanel.close()
  void api.invoke.setOverlay(false)
}

function wireDialogs(): void {
  settingsPanel.addEventListener('close', () => {
    if (!settingsOpen) return
    settingsOpen = false
    void api.invoke.setOverlay(false)
  })
  downloadsPanel.addEventListener('close', () => {
    if (!downloadsOpen) return
    downloadsOpen = false
    void api.invoke.setDownloads(false)
  })
}

function applySettingsSync(sync: SettingsSync): void {
  currentScheme = sync.scheme
  currentAccent = sync.accent ?? '#6a4bd8'
  renderPrefs()
  applyTheme()
}

// ── действия и горячие клавиши ────────────────────────────────────────────

function createTab(url?: string): void {
  void api.invoke.createTab(url)
}

function navigateFromOmnibox(raw: string): void {
  const value = raw.trim()
  omnibox.shadowRoot?.querySelector<HTMLInputElement>('input')?.blur()
  omnibox.blur()
  const tab = activeTab()
  if (!tab) {
    createTab(value || undefined)
    return
  }
  if (value) void api.invoke.navigate(tab.id, value)
  else omnibox.value = tab.displayUrl ?? ''
}

function cycleTab(direction: 1 | -1): void {
  const snapshot = state
  if (!snapshot || snapshot.tabs.length < 2) return
  const index = snapshot.tabs.findIndex((tab) => tab.id === snapshot.activeId)
  const next = (index + direction + snapshot.tabs.length) % snapshot.tabs.length
  void api.invoke.selectTab(snapshot.tabs[next].id)
}

function handleShortcut(event: KeyboardEvent): boolean {
  if (event.key === 'F11') {
    event.preventDefault()
    api.window.toggleFullscreen()
    return true
  }
  if (event.key === 'Escape') {
    if (settingsOpen) {
      event.preventDefault()
      closeSettings()
      return true
    }
    if (downloadsOpen) {
      event.preventDefault()
      closeDownloads()
      return true
    }
    return false
  }
  if (!event.ctrlKey && !event.metaKey) return false
  const key = event.key.toLowerCase()
  switch (key) {
    case 't':
      event.preventDefault()
      if (event.shiftKey) void callAction(api.invoke.reopenTab(), 'Вернуть вкладку')
      else createTab()
      return true
    case 'w': {
      event.preventDefault()
      const activeId = state?.activeId
      if (activeId !== null && activeId !== undefined) {
        void callAction(api.invoke.closeTab(activeId), 'Закрыть вкладку')
      }
      return true
    }
    case 'l':
      event.preventDefault()
      focusOmnibox()
      return true
    case 'tab':
      event.preventDefault()
      cycleTab(event.shiftKey ? -1 : 1)
      return true
    case 'r':
      event.preventDefault()
      void api.invoke.nav(event.shiftKey ? 'hard-reload' : 'reload')
      return true
    default:
      return false
  }
}

function wireChrome(): void {
  $('#new-tab').addEventListener('click', () => createTab())
  btnBack.addEventListener('click', () => void api.invoke.nav('back'))
  btnForward.addEventListener('click', () => void api.invoke.nav('forward'))
  btnReload.addEventListener('click', () => {
    const tab = activeTab()
    void api.invoke.nav(tab?.loading ? 'stop' : 'reload')
  })
  $('#btn-home').addEventListener('click', () => createTab())
  $('#btn-settings').addEventListener('click', () =>
    settingsOpen ? closeSettings() : openSettings(),
  )
  btnDownloads.addEventListener('click', () => (downloadsOpen ? closeDownloads() : openDownloads()))

  $('#win-min').addEventListener('click', () => api.window.minimize())
  $('#win-max').addEventListener('click', () => api.window.toggleMaximize())
  $('#win-close').addEventListener('click', () => api.window.close())
  $('#settings-done').addEventListener('click', closeSettings)
  $('#downloads-done').addEventListener('click', closeDownloads)
  $('#downloads-clear').addEventListener('click', () =>
    callAction(api.invoke.clearDownloads(), 'Очистить список'),
  )
  $('#downloads-open-folder').addEventListener('click', () =>
    callAction(api.invoke.openDownloadsFolder().then(showToast), 'Открыть папку'),
  )

  omnibox.addEventListener('search', (event) => {
    const detail = (event as CustomEvent<{ value?: string }>).detail
    navigateFromOmnibox(detail?.value ?? omnibox.value)
  })
  omnibox.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      event.preventDefault()
      event.stopPropagation()
      omnibox.value = activeTab()?.displayUrl ?? ''
      omnibox.shadowRoot?.querySelector<HTMLInputElement>('input')?.blur()
      omnibox.blur()
    }
  })
  document.addEventListener('keydown', handleShortcut)

  new ResizeObserver(() => measureChrome()).observe(chromeEl)
}

// ── подписки и запуск ─────────────────────────────────────────────────────

api.onState(applyState)
api.onToast(showToast)
api.onDownloadsUpdated((items) => {
  downloads = items
  renderDownloads()
})
api.onSettings(applySettingsSync)

async function init(): Promise<void> {
  buildSettings()
  wireChrome()
  wireDialogs()
  await refreshPrefs()
  await refreshDownloads()
  applyState(await api.invoke.state())
  measureChrome()
  void api.invoke.setDownloads(false)
}

void api.invoke.setDownloads(true).catch(() => {})
void init().catch((error) => {
  showToast(`Не удалось запустить браузер: ${error}`)
  void api.invoke.setDownloads(false).catch(() => {})
})
